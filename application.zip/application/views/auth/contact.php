<?php
	$this->load->view('auth/includes/header_layout');
?>	
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumb-->
    <div class="row pt-2 pb-2">
      <div class="col-sm-9">
        <h4 class="page-title">Dashboard</h4>
      </div>
    </div>
    <!-- End Breadcrumb-->
    <div class="row">
      <div class="col-lg-12">
<?php
    if(!empty($this->session->flashdata('success'))){
      ?>
      <div class="alert alert-light-success alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-check"></i>
            </div>
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('success');?></span>
            </div>
      </div>
      <?php
    }
    if(!empty($this->session->flashdata('error'))){
      ?>
      <div class="alert alert-light-danger alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-cross"></i>
            </div>
            <div class="alert-message">
              <span><strong>Error!</strong><?=$this->session->flashdata('error');?></span>
            </div>
      </div>
      <?php
    }
?>
        <div class="card">
          <div class="card-body">
            <div class="card-header"><i class="fa fa-table"></i> Reviews
              
            </div>
            <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Website</th>
                    <th>Subject</th>
                    <th>Message</th>                    
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    foreach ($contacts as $contact) {                      
                      ?>
                        <tr>
                          <td><?=$contact['full_name']?></td>
                          <td><?=$contact['email']?></td>
                          <td>
                            <?php 
                              if(empty($contact['website'])){
                                echo 'Not added';
                              }else{
                                echo $contact['website'];
                              }
                            ?>
                          </td>
                          <td><?=$contact['subject']?></td>
                          <td><?=wordwrap($contact['message'],35,"<br>\n");?></td>
                          
                          <td>
                            <a href="<?=base_url()?>admin/deleteContact/<?=$contact['id']?>" class="text-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                      <?php
                    }
                  ?> 
                </tbody>

              </table>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>
  <!-- End container-fluid-->
</div><!--End content-wrapper-->


<?php
	$this->load->view('auth/includes/footer_layout');
?>