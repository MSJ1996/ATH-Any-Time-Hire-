<?php
	$this->load->view('auth/includes/header_layout');
?>	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Dashboard</h4>
	   </div>
     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
		  <div style="height:600px"> 
		  <center>		      
          <h4>Welcome To Dashboard</h6>
          </center>
		  </div>
        </div>
      </div>

    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
<?php
	$this->load->view('auth/includes/footer_layout');
?>