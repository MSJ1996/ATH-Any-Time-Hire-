<?php
 /* echo "<pre>";
  print_r($bookings); die;*/ 
  $booking_location=array("Maharastra","Delhi/NCR","Bangolre","Hyderabad");
  $this->load->view('auth/includes/header_layout');
?>  
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumb-->
    <div class="row pt-2 pb-2">
      <div class="col-sm-9">
        <h4 class="page-title">Dashboard</h4>
      </div>
    </div>
    <!-- End Breadcrumb-->
    <div class="row">
      <div class="col-lg-12">
<?php
    if(!empty($this->session->flashdata('success'))){
      ?>
      <div class="alert alert-light-success alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-check"></i>
            </div>
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('success');?></span>
            </div>
      </div>
      <?php
    }
    if(!empty($this->session->flashdata('error'))){
      ?>
      <div class="alert alert-light-danger alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-cross"></i>
            </div>
            <div class="alert-message">
              <span><strong>Error!</strong><?=$this->session->flashdata('error');?></span>
            </div>
      </div>
      <?php
    }
?>
        <div class="card">
          <div class="card-body">
            <div class="card-header"><i class="fa fa-table"></i> All Bookings
              <!-- <button class="btn btn-primary shadow-primary btn-sm btn-round waves-effect waves-light" style="float: right;margin-bottom: 20px;" data-toggle="modal" data-target="#myModal">Add Vehicle</button> -->
            </div>
            <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Vechile Name</th>
                    <th>Customer Name</th>
                    <th>PickUp Location</th>
                    <th>DropUp Location</th>
                    <th>PickUp Date</th>
                    <th>DropUp Date</th>
                    
                    <th>Price</th>
                  </tr>
                </thead>
                <tbody>
                   <?php
                    foreach ($bookings as $bookings) {                      
                      ?>
                        <tr>
                          <td><?=$bookings['name'];?></td>
                          <td><?=$bookings['fname'].' '.$bookings['lname'] ;?></td>
                          <td><?=$booking_location[$bookings['pickup_location']]?></td>
                          <td><?=$booking_location[$bookings['drop_location']]?></td>
                          <td><?=$bookings['pick_up_date']?></td>
                          <td><?=$bookings['return_date']?></td>
                          <td><?=$bookings['price']?></td>
                          
                         
                        </tr>
                      <?php
                    }
                  ?> 
                </tbody>

              </table>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>
  <!-- End container-fluid-->
</div><!--End content-wrapper-->
<?php
  $this->load->view('auth/includes/footer_layout');
?>