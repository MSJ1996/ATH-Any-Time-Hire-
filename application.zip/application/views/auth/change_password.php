<?php
      $this->load->view('auth/includes/header_layout');
?>
<div class="clearfix"></div>      
  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
                  <div class="col-lg-10 mx-auto">
                     <div class="card">
                       <div class="card-body">
                           <div class="card-title"><?php echo lang('change_password_heading');?></div>
                           <hr>
                           <div id="infoMessage"><?php echo $message;?></div>
                            <?php echo form_open("auth/change_password");?>
                               <div class="form-group">
                                <label for="input-1"><?php echo lang('change_password_old_password_label', 'old_password');?></label>
                                 <?php echo form_input($old_password);?>
                               </div>
                               <div class="form-group">
                                <label for="input-2"><?php echo sprintf(lang('change_password_new_password_label'), $min_password_length);?></label>
                                <?php echo form_input($new_password);?>
                               </div>
                               <div class="form-group">
                                <label for="input-3"><?php echo lang('change_password_new_password_confirm_label', 'new_password_confirm');?></label>
                                <?php echo form_input($new_password_confirm);?>
                               </div>
                               
                               <div class="form-group">                                
                                <input type="submit" name="submit" value="Change" class="btn btn-primary shadow-primary px-5">                                
                              </div>
                             <?php echo form_close();?>
                         </div>
                     </div>
                  </div>
            </div>
      </div>
</div>
<?php
$this->load->view('auth/includes/footer_layout');
?>