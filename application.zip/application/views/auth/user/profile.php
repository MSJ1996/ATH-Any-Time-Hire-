<?php $this->load->view('auth/includes/header_layout');?>
<div class="clearfix"></div>      
<div class="content-wrapper">
	<div class="container-fluid">	
						<?php
						if(!empty($this->session->flashdata('success'))){
							?>
							<div class="alert alert-success alert-dismissible" role="alert">
							    <button type="button" class="close" data-dismiss="alert">&times;</button>
							    <div class="alert-icon contrast-alert">
								   <i class="icon-check"></i>
							    </div>
							    <div class="alert-message">
							      <span><strong>Success!</strong><?=$this->session->flashdata('success')?></span>
							    </div>
            				</div>
						<?php
						}
						if(!empty($this->session->flashdata('error'))){
							?>
							<div class="alert alert-danger alert-dismissible" role="alert">
							    <button type="button" class="close" data-dismiss="alert">&times;</button>
							    <div class="alert-icon contrast-alert">
								   <i class="icon-check"></i>
							    </div>
							    <div class="alert-message">
							      <span><strong>Error!</strong><?=$this->session->flashdata('error')?></span>
							    </div>
            				</div>
						<?php
						}
						?>
					<div class="card-body">
						<div class="row">
							<div class="col-lg-4">
								<div class="profile-card-3">
									<div class="card">
										<div class="user-fullimage">
											<img src="<?=base_url()?><?=$userdata[0]['image']?>" alt="user avatar" class="card-img-top" onclick="uploadpic()">
											<form method="post" action="<?=base_url()?>process/profilepic" enctype="multipart/form-data">
												<input class="file-upload" type="file" name="image" style="display: none;">
			     								<input type="submit" name="submit" class="button"
			     								style="display: none;">
			     							</form>
										</div>
										<div class="card-body text-center">
										<a href="<?=base_url()?>auth/change_password">Change Password</a>
										</div>	
									</div>
								</div>
							</div>
								<!-- second  -->
								<div class="col-lg-8">
									<div class="card">
										<div class="card-body">
											<ul class="nav nav-tabs nav-tabs-primary top-icon nav-justified">
												<li class="nav-item">
													<a href="javascript:void();" data-target="#profile" data-toggle="pill" class="nav-link active"><i class="icon-user"></i> <span class="hidden-xs">Profile</span></a>
												</li>
												
												<li class="nav-item">
													<a href="javascript:void();" data-target="#edit" data-toggle="pill" class="nav-link"><i class="icon-note"></i> <span class="hidden-xs">Edit</span></a>
												</li>
											</ul>
											<div class="tab-content p-3">
												<div class="tab-pane active" id="profile">
													<h5 class="mb-3">User Profile</h5>
													<div class="row">
														<div class="col-md-6">
															<h6>Name</h6>
															<p><?=$userdata[0]['first_name']?>&nbsp;<?=$userdata[0]['last_name']?></p>
															<h6>Email</h6>
															<p>
																<?=$userdata[0]['email']?>
															</p>
															<h6>Phone</h6>
															<p>
																<?=$userdata[0]['phone']?>
															</p>
														</div>							
													</div>
													<!--/row-->
												</div>												
												<div class="tab-pane" id="edit">
													<form method="post" action="<?=base_url()?>admin/edituser">
														<input type="hidden" name="id" value="<?=$userdata[0]['id']?>">
														<div class="form-group row">
															<label class="col-lg-3 col-form-label form-control-label">First name</label>
															<div class="col-lg-9">
																<input class="form-control" type="text" value="<?=$userdata[0]['first_name']?>" name="first_name" required>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-lg-3 col-form-label form-control-label">Last name</label>
															<div class="col-lg-9">
																<input class="form-control" type="text" value="<?=$userdata[0]['last_name']?>" name="last_name" required>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-lg-3 col-form-label form-control-label">Email</label>
															<div class="col-lg-9">
																<input class="form-control" type="email" value="<?=$userdata[0]['email']?>" name="email" required>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-lg-3 col-form-label form-control-label">Phone Number</label>
															<div class="col-lg-9">
																<input class="form-control" type="text" value="<?=$userdata[0]['phone']?>" name="phone" required>
															</div>
														</div>		
														<div class="form-group row">
															<label class="col-lg-3 col-form-label form-control-label"></label>
															<div class="col-lg-9">	
																<input type="submit" class="btn btn-primary shadow-primary px-5" value="Save Changes" style="float: right">
															</div>
														</div>
													</form>
												</div>
											</div>
										</div>
										<!-- ends here -->
									</div>
								</div>							
						</div>
					</div>
				</div>
			</div>
<?php $this->load->view('auth/includes/footer_layout');?>