<?php
$this->load->view('auth/includes/header_layout');
?>	
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumb-->
    <div class="row pt-2 pb-2">
      <div class="col-sm-9">
        <h4 class="page-title">Dashboard</h4>
      </div>
    </div>
    <!-- End Breadcrumb-->
    <div class="row">
      <div class="col-lg-12">
<?php
    if(!empty($this->session->flashdata('success'))){
      ?>
      <div class="alert alert-light-success alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-check"></i>
            </div>
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('success');?></span>
            </div>
      </div>
      <?php
    }
    if(!empty($this->session->flashdata('error'))){
      ?>
      <div class="alert alert-light-danger alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <div class="alert-icon">
           <i class="icon-check"></i>
            </div>
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('error');?></span>
            </div>
      </div>
      <?php
    }
?>
        <div class="card">
          <div class="card-body">
            <div class="card-header"><i class="fa fa-table"></i> Category
              <button class="btn btn-primary shadow-primary btn-sm btn-round waves-effect waves-light" style="float: right;margin-bottom: 20px;" data-toggle="modal" data-target="#myModal">Add Sub-Category</button>
            </div>
            <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                  <tr>
                    <th>Sub-Category Name</th>
                    <th>Category Name</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    foreach ($subcategoryData as $sc) {                      
                      ?>
                        <tr>
                          <td><?=$sc['subcategory_name']?></td>
                          <td><?=$sc['category_name']?></td>
                          <td><?=$sc['description']?></td>
                          <td><a href="javascript:void(null)" class="text-info" onclick="editSubcategory('<?=$sc['id']?>','<?=$sc['subcategory_name']?>','<?=$sc['category_id']?>','<?=$sc['description']?>')"><i class="fa fa-edit"></i></a></td>
                        </tr>
                      <?php
                    }
                  ?>
                </tbody>

              </table>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>
  <!-- End container-fluid-->
</div><!--End content-wrapper-->



<!-- modal code -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h5>Add Sub-Category</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?=base_url()?>vehicle/addSubcategory">
          <div class="form-group">
            <label>Category:</label>
            <select name="category_id" class="form-control">
              <option hidden>Select Category</option>
              <?php
                foreach ($categoryData as $cd) {
                 ?>
                  <option value="<?=$cd['id']?>"><?=$cd['category_name']?></option>
                 <?php
                }
              ?>
            </select>            
          </div>
          <div class="form-group">
            <label>Sub-Category Name</label>
            <input type="text" name="subcategory_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Description:</label>
            <textarea name="description" class="form-control" required></textarea>
          </div>
          <div>
            <input type="submit" name="submit" value="Add" class="btn btn-primary shadow-primary waves-light" style="float: right">
          </div>
        </form>
      </div>
    </div>

  </div>
</div>
<!-- edit modal code -->
<div id="editModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h5>Edit Sub-Category</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?=base_url()?>vehicle/updateSubcategory">
          <input type="hidden" name="id" class="subcat_id">
          <div class="form-group">
            <label>Sub-Category Name:</label>
            <input type="text" name="subcategory_name" class=" subname form-control" required>
          </div>
          <div class="form-group">
            <label>Category</label>
            <select class="cat_id form-control" name="category_id">
              <option hidden>Select Category</option>
              <?php
                foreach ($categoryData as $cd) {
                 ?>
                  <option value="<?=$cd['id']?>"><?=$cd['category_name']?></option>
                 <?php
                }
              ?>
            </select>
          </div>
          <div class="form-group">
            <label>Description:</label>
            <textarea name="description" class=" desc form-control" required></textarea>
          </div>
          <div>
            <input type="submit" name="submit" value="Update" class="btn btn-primary shadow-primary waves-light" style="float: right">
          </div>
        </form>
      </div>
    </div>

  </div>
</div>
<?php
$this->load->view('auth/includes/footer_layout');
?>  