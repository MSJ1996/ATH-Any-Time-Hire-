<?php
$this->load->view('auth/includes/header_layout');
?>	
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumb-->
    <div class="row pt-2 pb-2">
      <div class="col-sm-9">
        <h4 class="page-title">Dashboard</h4>
      </div>
    </div>
    <!-- End Breadcrumb-->
    <div class="row">
      <div class="col-sm-12">
        <div class="card"> 
          <div class="card-header"><i class="fa fa-edit"></i>Edit Vehicle</div>
          <div class="card-body row">
            <div class="col-sm-8">
              <form method="post" action="<?=base_url()?>vehicle/editVehicle">
                <input type="hidden" name="id" value="<?=$vehicle[0]['id']?>">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="name" class="form-control" required value="<?=$vehicle[0]['name']?>">
                </div>
                <div class="form-group">
                  <label>Category:</label>
                  <select name="category_id" class="form-control">
                    <option hidden>Select Category</option>
                    <?php
                        foreach ($category as $cat ) {
                         ?>
                            <option <?php if($vehicle[0]['category_id'] === $cat['id']) echo"selected"; ?> value="<?=$cat['id'];?>"><?=$cat['category_name'];?></option>
                         <?php
                        }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Sub-Category:</label>
                  <select name="subcategory_id" class="form-control">
                    <option hidden>Select Sub-Category</option>
                    <?php
                        foreach ($subcategory as $subcat ) {
                         ?>
                            <option <?php if($vehicle[0]['subcategory_id'] === $subcat['id']) echo"selected"; ?> value="<?=$subcat['id'];?>"><?=$subcat['subcategory_name'];?></option>
                         <?php
                        }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Description</label>
                  <textarea class="form-control" name="description"><?=$vehicle[0]['description']?></textarea>
                </div>
                <div class="form-group">
                  <label>Company Name</label>
                  <input type="text" name="company_name" class="form-control" required value="<?=$vehicle[0]['company_name']?>">
                </div>
                <div class="form-group">
                  <label>Price</label>
                  <input type="text" name="price" class="form-control" required value="<?=$vehicle[0]['price']?>">
                </div>
                <div class="form-group">
                  <input type="submit" name="submit" value="Update" class="btn btn-primary  waves-light" style="float: right">                  
                </div>
              </form>
            </div>
            <div class="col-sm-3">
              <img src="<?=base_url()?><?=$vehicle[0]['image']?>" width="200px" height="200px" style="margin-top: 30px">
            </div>
          </div>
        </div> 
        </div>
      </div>

    </div>
    <!-- End container-fluid-->

  </div><!--End content-wrapper-->
  <?php
  $this->load->view('auth/includes/footer_layout');
  ?>