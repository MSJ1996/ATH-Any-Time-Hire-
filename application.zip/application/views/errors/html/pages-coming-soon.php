<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Comming Soon</title>
  <!--favicon-->
  <link rel="icon" href="<?=base_url()?>public/assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="<?=base_url()?>public/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="<?=base_url()?>public/assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="<?=base_url()?>public/assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="<?=base_url()?>public/assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="<?=base_url()?>public/assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="<?=base_url()?>public/assets/css/app-style.css" rel="stylesheet"/>
  
</head>

<body class="bg-coming-soon">

<!-- Start wrapper-->
 <div id="wrapper">
 
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center coming-soon">
                       
                        <h2 class="coming-soon-title text-success">We are coming soon</h2>
                        <h6 class="text-white text-uppercase">Lets Join and work with us</h6> 
                        <div class="mt-4">
                          <a href="<?=base_url()?>" class="btn btn-success btn-round shadow-success m-1">Go To Home </a>
                          <a href="<?=$_SERVER['HTTP_REFERER'];?>" class="btn btn-outline-success btn-round m-1">Previous Page </a>
                        </div>
                         
                        <div class="mt-4">
                            <p class="text-dark">Copyright © 2018 | All rights reserved.</p>
                        </div>                                                    
                    </div>
                </div>
            </div>
        </div>

 </div><!--wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="<?=base_url()?>public/assets/js/jquery.min.js"></script>
  <script src="<?=base_url()?>public/assets/js/popper.min.js"></script>
  <script src="<?=base_url()?>public/assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="<?=base_url()?>public/assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?=base_url()?>public/assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?=base_url()?>public/assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?=base_url()?>public/assets/js/app-script.js"></script>
	
</body>
</html>
