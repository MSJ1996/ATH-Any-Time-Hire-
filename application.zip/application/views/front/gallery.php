<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our Gallery</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Check out the Gallery</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Gallery Page Content Start ==-->
    <section id="gallery-page-content" class="section-padding">
        <div class="container">
        	<div class="row">
        		<div class="col-lg-12">
					<div class="popular-cars-wrap">
						<!-- Filtering Menu -->
						<div class="popucar-menu text-center">
							<a href="#" data-filter="*" class="active">ALL</a>
							<a href="#" data-filter=".hat">HatchBack</a>
							<a href="#" data-filter=".sed">Sedan</a>
							<a href="#" data-filter=".suv">SUV</a>
							<a href="#" data-filter=".bike">Bikes</a>
							<a href="#" data-filter=".cycle">Cycle</a>
						</div>
						<!-- Filtering Menu -->
       			
						<div class="row popular-car-gird">
							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con hat">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/Swift.jpg">
										  <img src="<?=base_url()?>img/All Cars/Swift.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Maruti Suzuki Swift</a>
											<span class="price"><i class="fa fa-tag"></i> ₹1500/100 Km</span>
										</h3>

										<h5>Hatchback</h5>

										<div class="p-car-feature">
											<a href="#">2019</a>
											<a href="#">Manual</a>
											<a href="#">1.3Ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con hat ">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/i20.jpg">
										  <img src="<?=base_url()?>img/All Cars/i20.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Hyundai i20</a>
											<span class="price"><i class="fa fa-tag"></i> ₹2500/150 Km</span>
										</h3>

										<h5>HATCHBACK</h5>

										<div class="p-car-feature">
											<a href="#">2018</a>
											<a href="#">Automatic</a>
											<a href="#">1.3 Ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 suv con sed">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/Verna.jpg">
										  <img src="<?=base_url()?>img/All Cars/Verna.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Hyundai Verna</a>
											<span class="price"><i class="fa fa-tag"></i> ₹2500/185 Km</span>
										</h3>

										<h5>HATCHBACK</h5>

										<div class="p-car-feature">
											<a href="#">2018</a>
											<a href="#">Manual</a>
											<a href="#">1.6 Ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con sed">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/Ciaz.jpg">
										  <img src="<?=base_url()?>img/All Cars/Ciaz.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Maruti Suzuki Ciaz</a>
											<span class="price"><i class="fa fa-tag"></i> ₹3500/250 Km</span>
										</h3>

										<h5>Sedan</h5>

										<div class="p-car-feature">
											<a href="#">2019</a>
											<a href="#">Automatic</a>
											<a href="#">1.5 ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con suv">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/marazo.jpg">
										  <img src="<?=base_url()?>img/All Cars/marazo.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Mahindra Marazzo</a>
											<span class="price"><i class="fa fa-tag"></i>₹4500/350 Km</span>
										</h3>

										<h5>SUV</h5>

										<div class="p-car-feature">
											<a href="#">2019</a>
											<a href="#">Manual</a>
											<a href="#">2.0 Ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con suv">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/X5.jpg">
										  <img src="<?=base_url()?>img/All Cars/X5.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">BMW X5</a>
											<span class="price"><i class="fa fa-tag"></i>₹5500/300 Km</span>
										</h3>

										<h5>Luxury SUV</h5>

										<div class="p-car-feature">
											<a href="#">2019</a>
											<a href="#">Automatic</a>
											<a href="#">3.0 Ltr Engine</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con bike">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/200R.jpg">
										  <img src="<?=base_url()?>img/All Cars/200R.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Apachae 200R</a>
											<span class="price"><i class="fa fa-tag"></i>₹2500/150 Km</span>
										</h3>

										<h5>Sport Bike</h5>

										<div class="p-car-feature">
											<a href="#">2018</a>
											<a href="#">5 Speed Manual</a>
											<a href="#">199cc</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con bike">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/Hornet.jpg">
										  <img src="<?=base_url()?>img/All Cars/Hornet.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Honda Hornet</a>
											<span class="price"><i class="fa fa-tag"></i>₹1500/200 Km</span>
										</h3>

										<h5>Sport Bike</h5>

										<div class="p-car-feature">
											<a href="#">2017</a>
											<a href="#">5 Speed Manual</a>
											<a href="#">180cc</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->

							<!-- Single Popular Car Start -->
							<div class="col-lg-4 col-md-6 con cycle">
								<div class="single-popular-car">
									<div class="p-car-thumbnails">
										<a class="car-hover" href="<?=base_url()?>img/All Cars/MADDOX.jpg">
										  <img src="<?=base_url()?>img/All Cars/MADDOX.jpg" alt="JSOFT">
									   </a>
									</div>

									<div class="p-car-content">
										<h3>
											<a href="#">Herculus MADDOX</a>
											<span class="price"><i class="fa fa-tag"></i>₹3/Day</span>
										</h3>

										<h5>Paddles</h5>

										<div class="p-car-feature">
											<a href="#">2018</a>
											<a href="#">Man Force</a>
											<a href="#">21 Gaer</a>
										</div>
									</div>
								</div>
							</div>
							<!-- Single Popular Car End -->
						</div>
        			</div>
        		</div>
        	</div>
        </div>
    </section>
    <!--== Gallery Page Content End ==-->

    <!--== Footer Area Start ==-->
   <?php
    $this->load->view('front/includes/footer');
?>