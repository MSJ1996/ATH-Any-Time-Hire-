<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>FAQ's</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Popular Query.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== FAQ Area Start ==-->
    <section id="faq-page-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- FAQ Content Start -->
				<div class="col-lg-8">
					<div class="faq-details-content">
						<!-- Single FAQ Subject  Start -->
						<div class="single-faq-sub">
							<h3>Payment</h3>
							<div class="single-faq-sub-content">
								<div id="accordion">
									<!-- Single FAQ Start -->
									<div class="card">
										<div class="card-header" id="headingOne">
											<h5 class="mb-0"><button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
												<span>What is Peak Season? Are the prices different during Peak Season?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>

										<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
											<div class="card-body">
												Hourly rates are different for Mon-Thu, Fri-Sun and Peak Season. Please have a look at the dates for Peak Season here. The prices are mentioned on the tariff page.
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->
									
									<!-- Single FAQ Start -->
									<div class="card">
										<div class="card-header" id="headingTwo">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									  			<span>Who pays for fuel?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
									  		</button></h5>
										</div>
										<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
											<div class="card-body">
												Unlike other car hire services, ATH always pays for the fuel, regardless of whether the vehicle is a diesel or petrol variant. ATH refuels the vehicles regularly. If you are driving a long distance and you need to refuel the vehicle, just give your fuel receipt to the Fleet Executive after your reservation and ATH will happily reimburse you the full amount.
											</div>
										</div>
									</div>
									<!-- Single FAQ Start -->
									
									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingThree">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									  			<span>Is there a km limit to how much I can drive?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
											<div class="card-body">
												Each reservation comes with 10 km/hr with a maximum daily driving limit of 240 km/day (24 hour period). For example, a 5 hour reservation would come with 50 km in driving at no additional charge while a 3 day reservation would come with 720 km in driving at no additional charge. There is a per-km charge for each km beyond that point. Please see ATH tariffs for more details.
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->

									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingFour">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
									  			<span>What are the requirements when I drive across a State border?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
											<div class="card-body">
												Each State has different procedures. All States will require a commercially registered vehicle to stop at the border RTO station to pay the relevant tolls/taxes to obtain a valid entry permit. All ATH vehicles contain original copies of the RC Card, Insurance Note, Self-Drive License, and the All India Permit. In the event that an incident arises, please call ATH 24 hour Call Center at 9067053159 and we will provide the necessary guidance to the RTO officer to ensure the issue is resolved and you're back Zooming as soon as possible!
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->

									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingFive">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
									  			<span>What documents must I show at the State border RTO office after crossing a State border?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
											<div class="card-body">
												You must show copies of the RC Card, Insurance Note, Self-Drive License, and the All India Permit.
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->

									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingSix">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
									  			<span>What do I do if a border officer at the State RTO crossing is causing a problem?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
											<div class="card-body">
												This should not occur since each ATH vehicle is outfitted with all necessary documents. In the event that an incident does arise, please call Zoomcar's 24 hour Call Center at 9067053159 and we will provide the necessary guidance to the RTO officer to ensure the issue is resolved and you are back Zooming as soon as possible! ATH will not reimburse the member for any additional charges levied by RTO enforcement.
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->
								</div>
							</div>
						</div>
						<!-- Single FAQ Subject End -->
						
						<!-- Single FAQ Subject  Start -->
						<div class="single-faq-sub">
							<h3>Joining ATH</h3>
							<div class="single-faq-sub-content">
								<div id="accordion_2">
									<!-- Single FAQ Start -->
									<div class="card">
										<div class="card-header" id="heading4">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
												<span>What type of Drive's License is required?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>

										<div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion_2">
											<div class="card-body">
												ATH requires a valid Indian driver's license. It's critical that the license is an original. The License must be for a light motor vehicle (car). Members do NOT need a specific cab license that is associated with a yellow board plate.
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->
									
									<!-- Single FAQ Start -->
									<div class="card">
										<div class="card-header" id="headingSeven">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
									  			<span>What happen if I return a car Late?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
									  		</button></h5>
										</div>
										<div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordion_2">
											<div class="card-body">
												a) Standard hourly fee will be applicable per hour of delay. Weekend or weekday delays will be charged accordingly.
												b) Free KMs will be given at 10 km per hour of delay.
												c) In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300/hour.
											</div>
										</div>
									</div>
									<!-- Single FAQ Start -->
									
									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingEight">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
									  			<span>Is there a home delivery Option?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordion_2">
											<div class="card-body">
												Yes, at ATH we provide Doorstep Service for a fee of INR 300 for both car delivery and collection which has to be paid at the time of booking
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->
									
									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingNine">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
									  			<span>Do I need to provide any ID proof before taking the car?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordion_2">
											<div class="card-body">
												Yes, you will have to produce a government verified original ID proof to our driver,he can take a pic of it in case needed
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->

									<!-- Single FAQ End -->
									<div class="card">
										<div class="card-header" id="headingTen">
											<h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
									  			<span>How long do refunds takes?</span>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
											</button></h5>
										</div>
										<div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordion_2">
											<div class="card-body">
												PayTM (Instant refund), Simpl (1 day), PhonePe (1 day) • ICICI, HDFC, CITI, AXIS, KOTAK : Net banking (1-3 days), Credit card (5-7 days), Debit card (5-7 days) • ALL OTHER BANKS : Net banking (7-10 days), Credit card (7-10 days), Debit card (7-10 days).
											</div>
										</div>
									</div>
									<!-- Single FAQ End -->
								</div>
							</div>
						</div>
						<!-- Single FAQ Subject End -->
					</div>
				</div>
                <!-- FAQ Content End -->

                <!-- Sidebar Area Start -->
                <div class="col-lg-4">
                    <div class="sidebar-content-wrap m-t-50">
                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>For More Informations</h3>

                            <div class="sidebar-body">
                                <p><i class="fa fa-mobile"></i> +91 9067053159</p>
                                <p><i class="fa fa-clock-o"></i> 24x7..Service</p>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->

                       <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Rental Tips</h3>

                            <div class="sidebar-body">
                                <ul class="recent-tips">
                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service1-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">You certainly do have a very regular customer here... Must say, Greg went that extra mile... You have a great journey together!</a></h4>
                                            <span class="date">September 6, 2018</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service3-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">It was great pleasure use zoom service, As all process being online it was really hassle free experience. good service please keep it going</a></h4>
                                            <span class="date">December 31, 2018</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service2-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">I could not believe my ears on the benefits, especially the reimbursement of fuel. I would surely continue to use your professional services in months to come.</a></h4>
                                            <span class="date">February 25, 2019</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service3-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">Select your car. Pay. Drive. Return. The zoomcar booking process is as simple as this. Butter cannot be smoother than this.</a></h4>
                                            <span class="date">March 5, 2019</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->



                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Connect with Us</h3>

                            <div class="sidebar-body">
                                <div class="social-icons text-center">
                                    <a href="https://www.facebook.com/Any-Time-Hire-2364471966898508/?modal=admin_todo_tour"><i class="fa fa-facebook"></i></a>
                                    <a href="https://twitter.com/ManishSanjayJo2" target="_blank"><i class="fa fa-twitter"></i></a>
                                    <a href="https://www.linkedin.com/company/any-time-hire/?viewAsMember=true" target="_blank"><i class="fa fa-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->
                    </div>
                </div>
                <!-- Sidebar Area End -->
            </div>
        </div>
    </section>
    <!--== FAQ Area End ==-->
    
    <!--== Footer Area Start ==-->
    <?php
    $this->load->view('front/includes/footer');
?>