<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our drivers</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Will be Dilevered by Driver ATH</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Driver Page Content Start ==-->
    <section id="driver-page-wrap" class="section-padding">
        <div class="container">
			<div class="row">
                <?php
                    foreach ($drivers as $driver) {
                        ?>
                            <!-- Single Driver Start-->
                <div class="col-lg-4 col-md-6">
                    <div class="single-driver-member">
                        <img src="<?=base_url()?><?=$driver['image']?>" alt="driver">
                        <div class="driver-mem-info">
                            <div class="driver-mem-sicons">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                            <h4><?=$driver['name']?> <span><?=$driver['description']?></span></h4>
                        </div>
                    </div>
                </div>
                <!-- Single Driver End --> 
                        <?php
                    }
                ?>
                
            </div>
        </div>
    </section>
    <!--== Driver Page Content End ==-->

    <!--== Footer Area Start ==-->
    <?php
    $this->load->view('front/includes/footer');
?>