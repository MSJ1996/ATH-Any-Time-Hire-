<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our Services</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>What are the packages are included in ATH</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Service Page Content Start ==-->
    <section id="service-page-wrapper" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Single Services Start -->
                    <div class="single-service-item">
                        <div class="service-item-thumb ser-thumb-bg-1"></div>
                        <div class="service-item-content">
                            <h3>RENTAL CAR</h3>
                            <p>We rent various types of vehicles like cars, bikes & Bicycles All you need to do is register on our site, upload your documentation proof & perform payments. Its a very transparent & easy to use service.</p>
                        </div>
                    </div>
                    <!-- Single Services End -->

                    <!-- Single Services Start -->
                    <div class="single-service-item">
                        <div class="service-item-thumb ser-thumb-bg-2 d-lg-none d-md-block"></div>
                        <div class="service-item-content">
                            <h3>LIFE INSURANCE</h3>
                            <p>It is similar to life insaurance system provided by airlines companies.Once you rent a vehicle, we'll be providing you a certain amount of life insaurance. its very cheap & doesn't cost you a dime!!! Because we Value your life and safety above all!!!</p>
                        </div>
                        <div class="service-item-thumb ser-thumb-bg-2 d-none d-lg-block d-md-none"></div>
                    </div>
                    <!-- Single Services End -->

                    <!-- Single Services Start -->
                    <div class="single-service-item">
                        <div class="service-item-thumb ser-thumb-bg-3"></div>
                        <div class="service-item-content">
                            <h3>TAXI SERVICE</h3>
                            <p>Taxi driver doesn't necessarily mean a cab driver. the driver services are provided by us for our special customer, believe us or not, but all our customers are special for us! That means anyone can ask for a driver for their rental vehicals as an additional services.!!</p>
                        </div>
                    </div>
                    <!-- Single Services End -->

                    <!-- Single Services Start -->
                    <div class="single-service-item">
                        <div class="service-item-thumb ser-thumb-bg-4 d-lg-none d-md-block"></div>
                        <div class="service-item-content">
                            <h3>CALL DRIVER</h3>
                            <p>We do have very skilled, honest, hard working & criminal-records free drivers with us They ensure your trip shall go safe, sound, peaceful & most important of all, without any trouble. All you have to do is give a call to the driver alloted to you.!!</p>
                        </div>
                        <div class="service-item-thumb ser-thumb-bg-2 d-none d-lg-block d-md-none"></div>
                    </div>
                    <!-- Single Services End -->
                </div>
            </div>
        </div>
    </section>
    <!--== Service Page Content End ==-->
    <!--== Services Area Start ==-->
    <section id="service-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Section Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our Services</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>We care for Our Customer Safety.</p>
                    </div>
                </div>
                <!-- Section Title End -->
            </div>

           
            <!-- Service Content Start -->
            <div class="row">
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-taxi"></i>
                        <h3>RENTAL CAR</h3>
                        <p>We allow Clients to Rent a Car from any where across the India...</p>
                    </div>
                </div>
                <!-- Single Service End -->
                
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-cog"></i>
                        <h3>CAR INSPECTION</h3>
                        <p>We inspect the car before we deliver to the Client</p>
                    </div>
                </div>
                <!-- Single Service End -->
                
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-map-marker"></i>
                        <h3>AIRPORT SERVICE</h3>
                        <p>We allow the Client to book the car 15 min before Arrival...</p>
                    </div>
                </div>
                <!-- Single Service End -->
                
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-life-ring"></i>
                        <h3>LIFE INSURANCE</h3>
                        <p>We allow Insurance At just Rs 150/- Any any time,Anywhere...</p>
                    </div>
                </div>
                <!-- Single Service End -->
                
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-bath"></i>
                        <h3>CAR WASH</h3>
                        <p>We have Selected location where u can Wash Your Car</p>
                    </div>
                </div>
                <!-- Single Service End -->
                
                <!-- Single Service Start -->
                <div class="col-lg-4 text-center">
                    <div class="service-item">
                        <i class="fa fa-phone"></i>
                        <h3>CALL DRIVER</h3>
                        <p>We have Driver Assist at Pickup point and Dropoff Point</p>
                    </div>
                </div>
                <!-- Single Service End -->
            </div>
            <!-- Service Content End -->
        </div>
    </section>
    <!--== Services Area End ==-->

    <!--== Partner Area Start ==-->
    <div id="partner-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="partner-content-wrap">
                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-2.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-3.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-5.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== Partner Area End ==-->

    <!--== Testimonials Area Start ==-->
    <section id="testimonial-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Section Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Testimonials</h2>
                        <span class="title-line"><i class="fa fa-comments"></i></span>
                        <p>Clients Share Thier Experience.</p>
                    </div>
                </div>
                <!-- Section Title End -->
            </div>

            <div class="row">
                <div class="col-lg-8 col-md-12 m-auto">
                    <div class="testimonial-content">
                        <!--== Single Testimoial Start ==-->
                        <div class="single-testimonial">
                            <p>ATH partner program has made my dream come true. To have a car where it can earn its EMI by itself.</p>
                            <h3>Prabhakar Singh</h3>
                            <div class="client-logo">
                                <img src="<?=base_url()?>public/front/assets/img/client/PANDA2.jpg" alt="JSOFT">
                            </div>
                        </div>
                        <!--== Single Testimoial End ==-->

                        <!--== Single Testimoial Start ==-->
                        <div class="single-testimonial">
                            <p>My intention to attach a car was purely business. The real time updates of my vehicle details on the mobile application gives all the information I need at my finger tips.By far I am sure I have chosen the right place to invest. KUDOS!</p>
                            <h3>Prasad Gattewar</h3>
                            <div class="client-logo">
                                <img src="<?=base_url()?>public/front/assets/img/client/PG1.png" alt="JSOFT">
                            </div>
                        </div>
                        <!--== Single Testimoial End ==-->

                        <!--== Single Testimoial Start ==-->
                        <div class="single-testimonial">
                            <p>I have deployed a Hyundai grand i10 inJustConnect programme. I initially thought it would be risky and time taking but I literally did not spend any time off my work. It was like a snap of finger, my car was procured and deployed in fleet in a hassle free manner without much of my intervention.</p>
                            <h3>Uma Dhadkar</h3>
                            <div class="client-logo">
                                <img src="<?=base_url()?>public/front/assets/img/client/UMA.png" alt="JSOFT">
                            </div>
                        </div>
                        <!--== Single Testimoial End ==-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--== Testimonials Area End ==-->

    <!--== Footer Area Start ==-->
  <?php
    $this->load->view('front/includes/footer');
?>