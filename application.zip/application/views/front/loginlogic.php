<?php
session_start();
$user=$_POST["u"];
$pass=$_POST["p"];
$conn=mysqli_connect("localhost","root","","ath") or die("connection couldn't");
$query="select * from users where username='$user'";
$res=mysqli_query($conn,$query);
while($row=mysqli_fetch_array($res))
{
		
	$dbuser=$row["username"];
	$dbpass=$row["password"];
	$dbaccess=$row["access"];
	$_SESSION["uname"]=$dbuser;
	if($user==$dbuser && $pass==$dbpass)
	{
		if($dbaccess=="admin")
		{
			header("location:adminprofile.php");
		}
		else
		{
			header("location:userprofile.php");
		}
	}
	else
	{
		echo "username or password not matched";
	}
}
?>