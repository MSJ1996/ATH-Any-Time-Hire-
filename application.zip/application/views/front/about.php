<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>About US</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Lets describe about Ourself</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== About Page Content Start ==-->
    <section id="about-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Section Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our Responsibility</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>We care for Client</p>
                    </div>
                </div>
                <!-- Section Title End -->
            </div>

            <div class="row">
                <!-- About Content Start -->
                <div class="col-lg-6">
                    <div class="display-table">
                        <div class="display-table-cell">
                            <div class="about-content">
                                <p>We are pleased to inform you that we have finally accomplished the goal!!! We provide you 24x7 services to hire any vehicle(car,bike,bicycle and etc) of your choice at the place of your wish & that too with the driver selected by you!!!</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- About Content End -->

                <!-- About Video Start -->
                <div class="col-lg-6">
                    <div class="about-image">
                        <img src="<?=base_url()?>public/front/assets/img/home-2-about.png" alt="JSOFT">
                    </div>
                </div>
                <!-- About Video End -->
            </div>
        </div>
    </section>
    <!--== About Page Content End ==-->
    
    <!--== Our Facility Content Start ==-->
    <section id="our-facility" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Single Facility Start -->
                <div class="col-lg-3 col-md-6">
                    <div class="single-our-facility">
                        <h3>PARTY RENT</h3>
                        <ul>
                            <li>Exclusive Offers</li>
                            <li>Interactive and Fun</li>
                            <li>Responsive and Refined</li>
                            <li>Fuel Free</li>
                            <li>Acomodation on Request</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Facility Start -->
                
                <!-- Single Facility Start -->
                <div class="col-lg-3 col-md-6">
                    <div class="single-our-facility">
                        <h3>LUXURY CAR ON RENT</h3>
                        <ul>
                            <li>Ride on High level Car</li>
                            <li>Used for Business Purpose</li>
                            <li>High class ride</li>
                            <li>Avialable at any Movement</li>
                            <li>Fuel are Inculded</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Facility Start -->

                <!-- Single Facility Start -->
                <div class="col-lg-3 col-md-6">
                    <div class="single-our-facility">
                        <h3>HOTEL/CASINO/HOTEL</h3>
                        <ul>
                            <li>Free Pickup and Drop Services</li>
                            <li>Waiting will be there</li>
                            <li>Driver will arive on time</li>
                            <li>Free Waiting</li>
                            <li>Special Drivers will be there</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Facility Start -->

                <!-- Single Facility Start -->
                <div class="col-lg-3 col-md-6">
                    <div class="single-our-facility">
                        <h3>AIRPORT TRANSPORT</h3>
                        <ul>
                            <li>Driver will be there at Arrival</li>
                            <li>Driver will be there at Departure</li>
                            <li>Will be able to get the data from cient</li>
                            <li>Free Parking Zone</li>
                            <li>Providing u the SUV car</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Facility Start -->  
            </div>
        </div>
    </section>
    <!--== Our Facility Content End ==-->

    <!--== Partner Area Start ==-->
    <div id="partner-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="partner-content-wrap">
                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-2.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-3.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-5.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== Partner Area End ==-->

     <!--== Help Desk Page Content Start ==-->
    <section id="help-desk-page-wrap" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="team-content">
                        <div class="row">
                            <!-- Team Tab Menu start -->
                            <div class="col-lg-4">
                                <div class="team-tab-menu">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="tab_item_1" data-toggle="tab" href="#team_member_1" role="tab" aria-selected="true">
                                                <div class="team-mem-icon">
                                                    <img src="<?=base_url()?>public/front/assets/img/partner/MSJ2.png" alt="JSOFT">
                                                </div>
                                                <h5>Manish Sanjay Joshi</h5>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="tab_item_2" data-toggle="tab" href="#team_member_2" role="tab" aria-selected="true">
                                                <div class="team-mem-icon">
                                                    <img src="<?=base_url()?>public/front/assets/img/partner/nypic1.png" alt="JSOFT">
                                                </div>
                                                <h5>Nachiket Chavan</h5>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Team Tab Menu End -->

                            <!-- Team Tab Content start -->
                            <div class="col-lg-8">
                                <div class="tab-content" id="myTabContent">
                                    <!-- Single Team  start -->
                                    <div class="tab-pane fade show active" id="team_member_1" role="tabpanel" aria-labelledby="tab_item_1">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6">
                                                <div class="team-member-pro-pic">
                                                    <img src="<?=base_url()?>public/front/assets/img/partner/MSJ1.png" alt="JSOFT">
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <div class="team-member-info text-center">
                                                    <h4>Manish Sanjay Joshi</h4>
                                                    <h5>Director and CEO</h5>
                                                    <span class="quote-icon"><i class="fa fa-quote-left"></i></span>
                                                    <p>Taking an New Step to Implement My ATH system..With all new Features and Stuff. I'm The Director and CEO of ATH System pvt ltd..</p>
                                                    <div class="team-social-icon">
                                                        <a href="https://www.facebook.com/Any-Time-Hire-2364471966898508/?modal=admin_todo_tour"><i class="fa fa-facebook"></i></a>
                                                        <a href="https://twitter.com/ManishSanjayJo2"><i class="fa fa-twitter"></i></a>
                                                        <a href="https://www.linkedin.com/company/any-time-hire/?viewAsMember=true"><i class="fa fa-linkedin"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Team  End -->

                                    <!-- Single Team  start -->
                                    <div class="tab-pane fade" id="team_member_2" role="tabpanel" aria-labelledby="tab_item_2">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6">
                                                <div class="team-member-pro-pic">
                                                    <img src="<?=base_url()?>public/front/assets/img/partner/ny.png" alt="JSOFT">
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <div class="team-member-info text-center">
                                                    <h4>Nachiket Chavan</h4>
                                                    <h5>Manager</h5>
                                                    <span class="quote-icon"><i class="fa fa-quote-left"></i></span>
                                                    <p>ATH is the one who knows the way,Goes the way,And shows the way.</p>
                                                    <div class="team-social-icon">
                                                        <a href="https://www.facebook.com/Any-Time-Hire-2364471966898508/?modal=admin_todo_tour"><i class="fa fa-facebook"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Team  End -->
                                </div>
                            </div>
                            <!-- Team Tab Content End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--== Help Desk Page Content End ==-->

    <!--== Footer Area Start ==-->
 <?php
    $this->load->view('front/includes/footer');
?>