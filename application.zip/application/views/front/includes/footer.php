<section id="footer-area">
    <!-- Footer Widget Start -->
    <div class="footer-widget-area">
        <div class="container">
            <div class="row">
                <!-- Single Footer Widget Start -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-footer-widget">
                        <h2>About Us</h2>
                        <div class="widget-body">
                            <img src="<?=base_url()?>public/front/assets/img/LOGO.jpg" alt="JSOFT">
                            <p> We provide you 24x7 services to hire any vehicle(car,bike,bicycle and etc).</p>
                        </div>
                        
                    </div>
                </div>
                <!-- Single Footer Widget End -->
                <!-- Single Footer Widget Start -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-footer-widget">
                        <h2>Recent Posts</h2>
                        <div class="widget-body">
                            <ul class="recent-post">
                                <li>
                                    <a href="#">
                                        Great Services! 
                                        <i class="fa fa-long-arrow-right"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        Gud Quality Vehicals
                                        <i class="fa fa-long-arrow-right"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        Fast Driver Facility! 
                                        <i class="fa fa-long-arrow-right"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        Many More?
                                        <i class="fa fa-long-arrow-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Widget End -->
                <!-- Single Footer Widget Start -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-footer-widget">
                        <h2>Get in touch</h2>
                        <div class="widget-body">
                            <p>We have 24x7..Service assist contact anytime at the given below details.</p>
                            <ul class="get-touch">
                                <li><i class="fa fa-map-marker"></i> Maharashtra Pune/Baner</li>
                                <li><i class="fa fa-mobile"></i> +91 9067053159</li>
                                <li><i class="fa fa-envelope"></i> info@ath-system.co.in</li>
                            </ul>
                            <a href="https://www.google.com.bd/maps/place/Oakwood+Hills+Housing+Society/@18.558149,73.7821704,17z/data=!3m1!4b1!4m5!3m4!1s0x3bc2bed00a61051f:0xb0f6d7a6b3136631!8m2!3d18.558149!4d73.7843591?hl=en" class="map-show" target="_blank"><i class="fa fa-map"></i> Show Location</a>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Widget End -->
            </div>
        </div>

    <head>
    <!-- Start of  Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=b270220d-956f-41bd-809c-67641d315fd3"> </script>
    <!-- End of  Zendesk Widget script -->
    </head>
    </div>
    <!-- Footer Widget End -->
    <!-- Footer Bottom Start -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> (ATH) All rights reserved | This is made by <a href="https://colorlib.com" target="_blank">MSJ</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Bottom End -->
</section>
<!--== Footer Area End ==-->
<!--== Scroll Top Area Start ==-->
<div class="scroll-top">
    <img src="<?=base_url()?>public/front/assets/img/scroll-top.png" alt="JSOFT">
</div>
<!--== Scroll Top Area End ==-->
<!--=======================Javascript============================-->
<!--=== Jquery Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/jquery-3.2.1.min.js"></script>
<!--=== Jquery Migrate Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/jquery-migrate.min.js"></script>
<!--=== Popper Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/popper.min.js"></script>
<!--=== Bootstrap Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/bootstrap.min.js"></script>
<!--=== Gijgo Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/gijgo.js"></script>
<!--=== Vegas Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/vegas.min.js"></script>
<!--=== Isotope Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/isotope.min.js"></script>
<!--=== Owl Caousel Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/owl.carousel.min.js"></script>
<!--=== Waypoint Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/waypoints.min.js"></script>
<!--=== CounTotop Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/counterup.min.js"></script>
<!--=== YtPlayer Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/mb.YTPlayer.js"></script>
<!--=== Magnific Popup Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/magnific-popup.min.js"></script>
<!--=== Slicknav Min Js ===-->
<script src="<?=base_url()?>public/front/assets/js/plugins/slicknav.min.js"></script>
<!--=== Mian Js ===-->
<script src="<?=base_url()?>public/front/assets/js/main.js"></script>
<script>
    $(document).on('click','.rent-btn',function(){
        vclick=$(this);
        cid=$(vclick).data('id');
        vprice=$(vclick).parent('.car-list-info').find('.car_price').html();
        console.log(vprice);

        alert(cid);
        $.ajax({
            type:'POST',
            data:{id:cid,price:vprice},
            dataType:'JSON',
            url:"<?=base_url('Home/chkbooking_session')?>",
        }).done(function(data){
            if(data.status==1){
                window.location.href="<?php echo base_url('Home/cardPayment')?>";
            }else{
                alert('Before Proceed: Login And Booking is Mandatory')
            }
        })
    })
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip(); 
    });
</script>


</body>

</html>