<?php 
    
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Our Bikes</h2>
                        <span class="title-line"><i class="fa fa-motorcycle"></i></span>
                        <p>Time To go in Just Two Wheels.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Car List Area Start ==-->
    <section id="car-list-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Car List Content Start -->
                <div class="col-lg-12">
                    <div class="car-list-content">
                        <div class="row">
                            <?php
                                foreach ($bikes as $bike) {
                                   ?>
                            <!-- Single Car Start -->
                            <div class="col-lg-6 col-md-6">
                                <div class="single-car-wrap">
                                    <img src="<?=base_url()?><?=$bike['vimage']?>" alt="JSOFT">
                                    <div class="car-list-info without-bar">
                                        <h2><a href="#"><?=$bike['vname']?></a></h2>
                                        <h5>₹ <?=$bike['price']?> Rent /per a day</h5>
                                          <h6>Description.</h6>                 
                                        <p><?=$bike['description']?></p>
                                        <p class="rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </p>
                                        <a href="#" class="rent-btn">Book It</a>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Car End --> 
                                   <?php
                                }
                            ?>
                            
                        </div>
                    </div>
                </div>
                <!-- Car List Content End -->
            </div>
        </div>
    </section>
    <!--== Car List Area End ==-->

    <!--== Footer Area Start ==-->
    <?php
    $this->load->view('front/includes/footer');
?>