<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Contact Us</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Contact Anywhere, Anytime & Any Place</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Contact Page Area Start ==-->
    <div class="contact-page-wrao section-padding">
        <div class="container">
            <div class="row">
                <?php
    if(!empty($this->session->flashdata('success'))){
      ?>
      <div class="alert alert-light-success alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert"> ×</button>
            <div class="alert-icon">
           <i class="icon-check"></i>
            </div>
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('success');?></span>
            </div>
      </div>
      <?php
    }
    if(!empty($this->session->flashdata('error'))){
      ?>
      <div class="alert alert-danger alert-dismissible " role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>            
            <div class="alert-message">
              <span><strong>Success!</strong><?=$this->session->flashdata('error');?></span>
            </div>
      </div>
      <?php
    }
?>
                <div class="col-lg-10 m-auto">
                    <div class="contact-form">
                        <form action="<?=base_url()?>admin/addContact" method="post">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="name-input">
                                        <input type="text" placeholder="Full Name" required name="full_name">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="email-input">
                                        <input type="email" placeholder="Email Address" required name="email">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="website-input">
                                        <input type="text" placeholder="Website" name="website">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="subject-input">
                                        <input type="text" placeholder="Subject" required name="subject">
                                    </div>
                                </div>
                            </div>

                            <div class="message-input">
                                <textarea  cols="30" rows="10" placeholder="Message" required name="message"></textarea>
                            </div>

                            <div class="input-submit">
                                <button type="submit">Submit Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== Contact Page Area End ==-->
    <!--== Footer Area Start ==-->
   <?php
    $this->load->view('front/includes/footer');
?>