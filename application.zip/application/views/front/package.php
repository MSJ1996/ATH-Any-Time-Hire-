<?php
    $this->load->view('front/includes/header');
?>
    <!--== Header Area End ==-->

     <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>our packages</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>We give best package for the Client.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Pricing Area Start ==-->
    <section id="pricing-page-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Pricing Content Start -->
                <div class="col-lg-8">
                    <div class="pricing-details-content">
                        <div class="row">
                            <!-- Single Pricing Table -->
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="single-pricing-table">
                                    <h3>BUSINESS</h3>
                                    <h2>₹ 1500/-</h2>
                                    <h5>PER ANNUAL</h5>
                                    <ul class="package-list">
                                        <li>FREE DELIVERY</li>
                                        <li>FREE FUEL</li>
                                        <li>AIRPORT SERVICE</li>
                                        <li>DRIVER FACILITY</li>
                                        <li>30% OFF ON LUXURY CARS</li>
                                        <li>SAFETY FEATURES INCUDED</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Single Pricing Table -->

                            <!-- Single Pricing Table -->
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="single-pricing-table">
                                    <h3>Free Passes</h3>
                                    <h2>₹ 100/- OFF</h2>
                                    <h5>PER MONTH</h5>

                                    <ul class="package-list">
                                        <li>FREE VEHICLE DELIVERY</li>
                                        <li>SAFETY FEATURES INCUDED</li>
                                        <li>FULL INSURANCE</li>
                                        <li>TRANSPORT ABROAD</li>
                                        <li>50% OF ON MINI BAR</li>
                                        <li>INCLUDED IN PRICE</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Single Pricing Table -->

                            <!-- Single Pricing Table -->
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="single-pricing-table">
                                    <h3>CURRENT MEMBERSHIP</h3>
                                    <h2>Free</h2>
                                    <h5>PER MONTH</h5>          

                                    <ul class="package-list">
                                        <li>FREE VEHICLE DELIVERY</li>
                                        <li>DELIVERY AT AIRPORT</li>
                                        <li>FREE FUEL</li>
                                        <li>SAFETY FEATURES INCUDED</li>
                                        <li>30% OFF ON LUXURY CARS</li>
                                        <li>DRIVER OPTION</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Single Pricing Table -->

                            <!-- Single Pricing Table -->
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="single-pricing-table">
                                    <h3>STANDARD</h3>
                                    <h2>₹ 999/-</h2>
                                    <h5>QUATERLY</h5>

                                    <ul class="package-list">
                                        <li>DELIVERY AT AIRPORT</li>
                                        <li>PARTY AND OTHER EVENT</li>
                                        <li>FUEL INCLUDED</li>
                                        <li>TRANSPORT ACROSS INDIA</li>
                                        <li>SAFETY FEATURES INCUDED</li>
                                        <li>FREE INSAURANCE</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Single Pricing Table -->
                        </div>
                    </div>
                </div>
                <!-- Pricing Content End -->

                <!-- Sidebar Area Start -->
                <div class="col-lg-4">
                    <div class="sidebar-content-wrap m-t-50">
                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>For More Informations</h3>

                            <div class="sidebar-body">
                                <p><i class="fa fa-mobile"></i> +91 9067053159</p>
                                <p><i class="fa fa-clock-o"></i> 24x7 Service On</p>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->

                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Rental Tips</h3>

                            <div class="sidebar-body">
                                <ul class="recent-tips">
                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service1-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">You certainly do have a very regular customer here... Must say, Greg went that extra mile... You have a great journey together!</a></h4>
                                            <span class="date">September 6, 2018</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service3-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">It was great pleasure use zoom service, As all process being online it was really hassle free experience. good service please keep it going</a></h4>
                                            <span class="date">December 31, 2018</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service2-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">I could not believe my ears on the benefits, especially the reimbursement of fuel. I would surely continue to use your professional services in months to come.</a></h4>
                                            <span class="date">February 25, 2019</span>
                                        </div>
                                    </li>

                                    <li class="single-recent-tips">
                                        <div class="recent-tip-thum">
                                            <a href="#"><img src="<?=base_url()?>public/front/assets/img/we-do/service3-img.png" alt="JSOFT"></a>
                                        </div>
                                        <div class="recent-tip-body">
                                            <h4><a href="#">Select your car. Pay. Drive. Return. The zoomcar booking process is as simple as this. Butter cannot be smoother than this.</a></h4>
                                            <span class="date">March 5, 2019</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->

                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Connect with Us</h3>

                            <div class="sidebar-body">
                                <div class="social-icons text-center">
                                    <a href="https://www.facebook.com/Any-Time-Hire-2364471966898508/?modal=admin_todo_tour"><i class="fa fa-facebook"></i></a>
                                    <a href="https://twitter.com/ManishSanjayJo2" target="_blank"><i class="fa fa-twitter"></i></a>
                                    <a href="https://www.linkedin.com/company/any-time-hire/?viewAsMember=true" target="_blank"><i class="fa fa-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->
                    </div>
                </div>
                <!-- Sidebar Area End -->
            </div>
        </div>
    </section>
    <!--== FAQ Area End ==-->

    <!--== Footer Area Start ==-->
   <?php
    $this->load->view('front/includes/footer');
?>