<?php
$this->load->view('front/includes/header');
?>
<!--== Header Area End ==-->

<!--== Page Title Area Start ==-->
<section id="page-title-area" class="section-padding overlay">
    <div class="container">
        <div class="row">
            <!-- Page Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h2>Registration</h2>
                    <span class="title-line"><i class="fa fa-car"></i></span>
                    <p>Sign Up With the ATH System.</p>
                </div>
            </div>
            <!-- Page Title End -->
        </div>
    </div>
</section>
<!--== Page Title Area End ==-->

<!--== Login Page Content Start ==-->
<section id="lgoin-page-wrap" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-8 m-auto">
                <div class="login-page-content">
                    <div class="login-form">
                        <h3>Sign Up</h3>
                        <?php

                        $chk_flash=$this->session->flashdata('message');

                        if($chk_flash)
                        {
                            $status=$this->session->flashdata('status');

                            if($status==0){
                                ?>
                                <div class="alert alert-danger">
                                    <strong>Invalid Details!</strong>  <?=$this->session->flashdata('message')?>
                                </div>
                                <?php
                            }
                                else
                            {
                                ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong>  <?=$this->session->flashdata('message')?>
                                </div>
                                <?php
                            }

                        }

                        ?>
                        <form action="<?php echo base_url('Home/submitregistration')?>" method="post">
                            <div class="name">
                                <div class="row">
                                    <div class="col-md-6">
                                        <input type="text" placeholder="First Name" name="fname">
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" placeholder="Last Name" name="lname">
                                    </div>
                                </div>
                            </div>
                            <div class="username">
                                <input type="email" placeholder="Email" name="email">
                            </div>
                            <div class="username">
                                <input type="text" placeholder="License No" name="uname">
                            </div>
                            <div class="password">
                                <input type="password" placeholder="Password" name="password">
                            </div>
                            <div class="password">
                                <input type="password" placeholder="Confirm Password" name="cpassword">
                            </div>
                            <div class="log-btn">
                                <button type="submit"><i class="fa fa-check-square"></i> Sign Up</button>
                            </div>
                        </form>
                    </div>

                    <div class="login-other">
                        <span class="or">or</span>
                        
                    </div>
                    <div class="create-ac">
                        <p>Have an account? <a href="<?=base_url()?>home/login">Sign In</a></p>
                    </div>
                    <div class="login-menu">
                        <a href="<?=base_url()?>home/about">About</a>
                        <span>|</span>
                        <a href="<?=base_url()?>home/contact">Contact</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== Login Page Content End ==-->

<!--== Footer Area Start ==-->
<?php
$this->load->view('front/includes/footer');
?>