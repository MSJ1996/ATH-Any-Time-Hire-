<?php
/*echo "<pre>";
print_r($getCars); die;*/
$this->load->view('front/includes/header');
?>
<!--== Header Area End ==-->
<!--== Slider Area Start ==-->
<section id="slider-area">
    <!--== slide Item One ==-->
    <div class="single-slide-item overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="book-a-car">
                        <?php
                        $chk_flash=$this->session->flashdata('message');

                        if($chk_flash)
                        {
                            $status=$this->session->flashdata('status');

                            if($status==0){
                                ?>
                                <div class="alert alert-danger">
                                    <strong>Invalid!!</strong>  <?=$this->session->flashdata('message')?>
                                </div>
                                <?php
                            }else{
                                ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong>  <?=$this->session->flashdata('message')?>
                                </div>
                                <?php
                            }
                        }
                        ?>
                        <form action="<?php echo base_url('home/submitbooking')?>" method="post">
                            <!--== Pick Up Location ==-->
                            <div class="pickup-location book-item">
                                <h4>PICK-UP LOCATION:</h4>
                                <select class="custom-select" name="pickup_location">
                                    <option value="" selected>Pick Location</option>
                                    <option value="1">Maharastra/Pune</option>
                                    <option value="2">Delhi/NCR</option>
                                    <option value="3">Bangolre</option>
                                    <option value="3">Hyderabad</option>
                                </select>
                            </div>
                            <div class="dropoff-location book-item">
                                <h4>DROP-DOWN LOCATION:</h4>
                                <select class="custom-select" name="drop_location">
                                    <option value=""selected>Drop Location</option>
                                    <option value="1">Maharastra/Pune</option>
                                    <option value="2">Delhi/NCR</option>
                                    <option value="3">Bangolre</option>
                                    <option value="3">Hyderabad</option>   
                                </select>
                            </div>   
                            <!--== Pick Up Location ==-->
                            <!--== Pick Up Date ==-->
                            <div class="pick-up-date book-item">
                                <h4>PICK-UP DATE:</h4>
                                <input id="startDate" placeholder="Pick Up Date"  name="pick_up_date" />
                                <div class="return-car">
                                    <h4>Return DATE:</h4>
                                    <input id="endDate" placeholder="Return Date" name="return_date" />
                                </div>
                            </div>
                            <!--== Pick Up Location ==-->
                            <!--== Car Choose ==-->
                            <div class="choose-car-type book-item">
                                <h4>CHOOSE CAR TYPE:</h4>
                                <select class="custom-select" name="vehicle_id">
                                    <option value=""selected>Select</option>
                                    <?php
                                    if(!empty($getCars)){
                                        foreach ($getCars as $carkey => $carvalue) {
                                            ?>
                                            <option value="<?php echo $carvalue['vid']?>"><?php echo strtoupper($carvalue['vname'])?></option>
                                            <?php
                                        }
                                    }
                                    ?>


                                </select>
                            </div>
                            <!--== Car Choose ==-->
                            <div class="book-button text-center">
                                <button class="book-now-btn">Book Now</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-7 text-right">
                    <div class="display-table">
                        <div class="display-table-cell">
                            <div class="slider-right-text">
                                <h1>BOOK A CAR TODAY!</h1>
                                <p>STARTING FROM AS LOW AS ₹ 350/- A DAY <br> FOR OUR RETURNING CUSTOMERS</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== slide Item One ==-->
</section>
<!--== Slider Area End ==-->
<!--== What We Do Area Start ==-->
<section id="what-do-area" class="section-padding">
    <div class="container">
        <div class="row">
            <!-- Section Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h2>WHAT WE DO</h2>
                    <span class="title-line"><i class="fa fa-car"></i></span>
                    <p>Why we are here.</p>
                </div>
            </div>
            <!-- Section Title End -->
        </div>
        <div class="row">
            <!-- Single We Do Start -->
            <div class="col-lg-4 col-md-4">
                <div class="single-we-do we-do-bg-1">
                    <div class="we-do-content">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <h3>CAR INSPECTION</h3>
                                <p>We Inspect car before we deliver</p> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single We Do End -->
            <!-- Single We Do Start -->
            <div class="col-lg-4 col-md-4">
                <div class="single-we-do we-do-bg-2">
                    <div class="we-do-content">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <h3>CAR SAFETY</h3>
                                <p>We care for customer, We provide safety feature for our customers</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single We Do End -->
            <!-- Single We Do Start -->
            <div class="col-lg-4 col-md-4">
                <div class="single-we-do we-do-bg-3">
                    <div class="we-do-content">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <h3>BOOKING ON TIME</h3>
                                <p>We make sure that our customer don't wait for more than 60 seconds for booking</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single We Do End -->
        </div>
    </div>
</section>
<!--== What We Do Area End ==-->
<!--== Partner Area Start ==-->
<div id="partner-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="partner-content-wrap">
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-2.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-3.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->

                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-5.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-1.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                    <!-- Single Partner Start -->
                    <div class="single-partner">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <img src="<?=base_url()?>public/front/assets/img/partner/partner-logo-4.png" alt="JSOFT">
                            </div>
                        </div>
                    </div>
                    <!-- Single Partner End -->
                </div>
            </div>
        </div>
    </div>
</div>
<!--== Partner Area End ==-->
<!--== Services Area Start ==-->
<section id="service-area" class="section-padding">
    <div class="container">
        <div class="row">
            <!-- Section Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h3>Our Services</h3>
                    <span class="title-line"><i class="fa fa-car"></i></span>
                    <p>We care for Our Customer Safety.</p>
                </div>
            </div>
            <!-- Section Title End -->
        </div>
        <div class="row">
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-1.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                            <h4>RENTAL CAR</h4>
                            <p>We Allow Clients to Rent a Car from any where across the India...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-2.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                            <h4>CAR INSPECTION</h4>
                            <p>We Inspect the car before we deliver to the Client</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-3.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                            <h4>CALL DRIVER</h4>
                            <p>We have Driver Assist at Pickup point and Dropoff Point</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-4.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                            <h4>LIFE INSURANCE</h4>
                            <p>We allow Insurance At just ₹ 150/-</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-5.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                            <h4>CAR WASH</h4>
                            <p>We have Selected location where u can Wash Your Car</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
            <!-- Single Service Start -->
            <div class="col-lg-4 col-md-6">
                <div class="single-service">
                    <div class="media">
                        <div class="service-icon">
                            <span></span>
                            <img src="<?=base_url()?>public/front/assets/img/services/service-icon-6.png" alt="JSOFT">
                        </div>
                        <div class="media-body">
                             <h4>AIRPORT SERVICE</h4>
                            <p>We allow the Client to book the car 15 min before Arrival...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Service Start -->
        </div>
    </div>
</section>
<!--== Services Area End ==-->
<!--== Fun Fact Area Start ==-->
<section id="funfact-area" class="overlay section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-11 col-md-12 m-auto">
                <div class="funfact-content-wrap">
                    <div class="row">
                        <!-- Single FunFact Start -->
                        <div class="col-lg-4 col-md-6">
                            <div class="single-funfact">
                                <div class="funfact-icon">
                                    <i class="fa fa-smile-o"></i>
                                </div>
                                <div class="funfact-content">
                                    <p><span class="counter">10</span>+</p>
                                    <h4>HAPPY CLIENTS</h4>
                                </div>
                            </div>
                        </div>
                        <!-- Single FunFact End -->
                        <!-- Single FunFact Start -->
                        <div class="col-lg-4 col-md-6">
                            <div class="single-funfact">
                                <div class="funfact-icon">
                                    <i class="fa fa-car"></i>
                                </div>
                                <div class="funfact-content">
                                    <p><span class="counter">250</span>+</p>
                                    <h4>CARS IN STOCK</h4>
                                </div>
                            </div>
                        </div>
                        <!-- Single FunFact End -->
                        <!-- Single FunFact Start -->
                        <div class="col-lg-4 col-md-6">
                            <div class="single-funfact">
                                <div class="funfact-icon">
                                    <i class="fa fa-bank"></i>
                                </div>
                                <div class="funfact-content">
                                    <p><span class="counter">2</span>+</p>
                                    <h4>BRANCH IN INDIA</h4>
                                </div>
                            </div>
                        </div>
                        <!-- Single FunFact End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== Fun Fact Area End ==-->
<!--== Our Cars Area Start ==-->
<section id="our-cars" class="section-padding">
    <div class="container">
        <div class="row">
            <!-- Section Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h2>Our cars</h2>
                    <span class="title-line"><i class="fa fa-car"></i></span>
                    <p>Best Wheels </p>
                </div>
            </div>
            <!-- Section Title End -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="team-content">
                    <div class="row">
                        <!-- OurCars Tab Menu start -->
                        <div class="col-lg-3">
                            <div class="ourcar-tab-menu">
                                <ul class="nav nav-tabs" id="ourcartabmenu" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="ourcar_item_1" data-toggle="tab" href="#ourcar_1" role="tab" aria-selected="true">Mercedes-Benz GLS</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="ourcar_item_2" data-toggle="tab" href="#ourcar_2" role="tab" aria-selected="true">Audi A6</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="ourcar_item_3" data-toggle="tab" href="#ourcar_3" role="tab" aria-selected="true">Maruti Suzuki Ciaz</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="ourcar_item_4" data-toggle="tab" href="#ourcar_4" role="tab" aria-selected="true">Renault Capture</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="ourcar_item_5" data-toggle="tab" href="#ourcar_5" role="tab" aria-selected="true">Toyota Innova Crsyta</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- OurCars Tab Menu End -->
                        <!-- OurCars Tab Content start -->
                        <div class="col-lg-9">
                            <div class="tab-content" id="ourcartabcontent">
                                <!-- Single OurCars  start -->
                                <div class="tab-pane fade show active" id="ourcar_1" role="tabpanel" aria-labelledby="ourcar_item_1">
                                    <div class="row">
                                        <div class="col-lg-8 text-center">
                                            <div class="display-table">
                                                <div class="display-table-cell">
                                                    <div class="ourcar-pic">
                                                        <img src="<?=base_url()?>img/All cars/GLS.jpg" alt="JSOFT">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="ourcar-info text-center">
                                                <h2>₹ 900/- <span>Rent per day</span></h2>
                                                <table class="our-table">
                                                    <tr>
                                                        <td>Model</td>
                                                        <td>Luxury</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Doors</td>
                                                        <td>4</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Seats</td>
                                                        <td>7</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transmission</td>
                                                        <td>Automatic</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Air conditioning</td>
                                                        <td>Yes</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single OurCars End -->
                                <!-- Single OurCars  start -->
                                <div class="tab-pane fade" id="ourcar_2" role="tabpanel" aria-labelledby="ourcar_item_2">
                                    <div class="row">
                                        <div class="col-lg-8 text-center">
                                            <div class="display-table">
                                                <div class="display-table-cell">
                                                    <div class="ourcar-pic">
                                                        <img src="<?=base_url()?>img/All cars/A6.jpg" alt="JSOFT">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="ourcar-info text-center">
                                                <h2>₹ 999/- <span>Rent per day</span></h2>
                                                <table class="our-table">
                                                    <tr>
                                                        <td>Model</td>
                                                        <td>Luxury</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Doors</td>
                                                        <td>4</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Seats</td>
                                                        <td>5</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transmission</td>
                                                        <td>Automatic</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Air conditioning</td>
                                                        <td>Yes</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single OurCars End -->
                                <!-- Single OurCars  start -->
                                <div class="tab-pane fade" id="ourcar_3" role="tabpanel" aria-labelledby="ourcar_item_3">
                                    <div class="row">
                                        <div class="col-lg-8 text-center">
                                            <div class="display-table">
                                                <div class="display-table-cell">
                                                    <div class="ourcar-pic">
                                                        <img src="<?=base_url()?>img/All cars/Ciaz.jpg" alt="JSOFT">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="ourcar-info text-center">
                                                <h2>₹ 780/- <span>Rent per day</span></h2>
                                                <table class="our-table">
                                                    <tr>
                                                        <td>Model</td>
                                                        <td>Sedan</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Doors</td>
                                                        <td>4</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Seats</td>
                                                        <td>5</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transmission</td>
                                                        <td>Automatic</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Air conditioning</td>
                                                        <td>Yes</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single OurCars End -->
                                <!-- Single OurCars  start -->
                                <div class="tab-pane fade" id="ourcar_4" role="tabpanel" aria-labelledby="ourcar_item_4">
                                    <div class="row">
                                        <div class="col-lg-8 text-center">
                                            <div class="display-table">
                                                <div class="display-table-cell">
                                                    <div class="ourcar-pic">
                                                        <img src="<?=base_url()?>img/All cars/Capture.jpg" alt="JSOFT">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="ourcar-info text-center">
                                                <h2>₹ 750/- <span>Rent per day</span></h2>
                                                <table class="our-table">
                                                    <tr>
                                                        <td>Model</td>
                                                        <td>Compact SUV</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Doors</td>
                                                        <td>4</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Seats</td>
                                                        <td>5</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transmission</td>
                                                        <td>Manual</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Air conditioning</td>
                                                        <td>Yes</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single OurCars End -->
                                <!-- Single OurCars  start -->
                                <div class="tab-pane fade" id="ourcar_5" role="tabpanel" aria-labelledby="ourcar_item_5">
                                    <div class="row">
                                        <div class="col-lg-8 text-center">
                                            <div class="display-table">
                                                <div class="display-table-cell">
                                                    <div class="ourcar-pic">
                                                        <img src="<?=base_url()?>img/All cars/Crysta.jpg" alt="JSOFT">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="ourcar-info text-center">
                                                <h2>₹ 980/- <span>Rent per day</span></h2>
                                                <table class="our-table">
                                                    <tr>
                                                        <td>Model</td>
                                                        <td>SUV</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Doors</td>
                                                        <td>4</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Seats</td>
                                                        <td>7</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Transmission</td>
                                                        <td>Automatic</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Air conditioning</td>
                                                        <td>Yes</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single OurCars End -->
                            </div>
                        </div>
                        <!-- OurCars Tab Content End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== Our Cars Area End ==-->
<!--== Pricing Area Start ==-->
<section id="pricing-area" class="section-padding overlay">
    <div class="container">
        <div class="row">
            <!-- Section Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h2>Choose Your Best Package</h2>
                        <span class="title-line"><i class="fa fa-inr"></i></span>
                        <p>We serve best for the Customer</p>
                </div>
            </div>
            <!-- Section Title End -->
        </div>
        <!-- Pricing Table Conatent Start -->
            <div class="row">
                <!-- Single Pricing Table -->
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="single-pricing-table">
                        <h3>BUSINESS</h3>
                        <h2>₹ 1500/-</h2>
                        <h5>PER ANNUAL</h5>

                        <ul class="package-list">
                            <li>FREE DELIVERY</li>
                            <li>FREE FUEL</li>
                            <li>FREE AIRPORT SERVICE</li>
                            <li>DRIVER FACILITY</li>
                            <li>30% OFF ON LUXURY CARS</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Pricing Table -->

                <!-- Single Pricing Table -->
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="single-pricing-table">
                        <h3>CURRENT MEMBERSHIP</h3>
                        <h2>Free</h2>
                        <h5>PER MONTH</h5>

                        <ul class="package-list">
                            <li>FREE VEHICLE DELIVERY</li>
                            <li>DELIVERY AT AIRPORT</li>
                            <li>FREE FUEL</li>
                            <li>PARTY EVENT ACCESS</li>
                            <li>DRIVER OPTION</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Pricing Table -->

                <!-- Single Pricing Table -->
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="single-pricing-table">
                        <h3>STANDARD</h3>
                        <h2>₹ 999/-</h2>
                        <h5>QUATERLY</h5>

                        <ul class="package-list">
                            <li>DELIVERY AT AIRPORT</li>
                            <li>PARTY AND OTHER EVENT</li>
                            <li>FUEL INCLUDED</li>
                            <li>TRANSPORT ACROSS INDIA</li>
                            <li>FREE INSAURANCE</li>
                        </ul>
                    </div>
                </div>
                <!-- Single Pricing Table -->
            </div>
            <!-- Pricing Table Conatent End -->
        </div>
         </section>
<!--== Pricing Area End ==-->

<!--== Mobile App Area Start ==-->
<div id="mobileapp-video-bg"></div>
<section id="mobile-app-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="mobile-app-content">
                    <h2>SAVE 30% WITH THE APP</h2>
                    <p>Easy &amp; Fast - Book a car in 60 seconds</p>
                    <p>Will be launching soon!!!</p>
                    <div class="app-btns">
                        <a href="#"><i class="fa fa-android"></i>Andriod</a>
                            <a href="#"><i class="fa fa-apple"></i>IOS</a>
                            <a href="#"><i class="fa fa-windows"></i>Windows</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== Mobile App Area End ==-->
<!--== Articles Area Start ==-->
<section id="tips-article-area" class="section-padding">
    <div class="container">
        <div class="row">
            <!-- Section Title Start -->
            <div class="col-lg-12">
                <div class="section-title  text-center">
                    <h2>Tips and articles</h2>
                    <span class="title-line"><i class="fa fa-car"></i></span>
                    <p>Customer Share Their Experinces</p>
                </div>
            </div>
            <!-- Section Title End -->
        </div>
        <!-- Articles Content Wrap Start -->
        <div class="row">
            <!-- Single Articles Start -->
            <div class="col-lg-12">
                <article class="single-article">
                    <div class="row">
                        <!-- Articles Thumbnail Start -->
                        <div class="col-lg-5">
                            <div class="article-thumb">
                                <img src="<?=base_url()?>public/front/assets/img/article/arti-thumb-1.jpg" alt="JSOFT">
                            </div>
                        </div>
                        <!-- Articles Thumbnail End -->
                        <!-- Articles Content Start -->
                        <div class="col-lg-7">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <div class="article-body">
                                        <h3><a href="article-details.html">Uma Dhadkar</a></h3>
                                        <div class="article-meta">
                                            <a href="#" class="author">By :: <span>Admin</span></a>
                                            <a href="#" class="commnet">Comments :: <span>10</span></a>
                                        </div>
                                        <div class="article-date">25 <span class="month">jan</span></div>
                                        <p>It was great pleasure use zoom service, As all process being online it was really hassle free experience. good service please keep it going.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Articles Content End -->
                    </div>
                </article>
            </div>
            <!-- Single Articles End -->
            <!-- Single Articles Start -->
            <div class="col-lg-12">
                <article class="single-article middle">
                    <div class="row">
                        <!-- Articles Thumbnail Start -->
                        <div class="col-lg-5 d-xl-none">
                            <div class="article-thumb">
                                <img src="<?=base_url()?>public/front/assets/img/article/arti-thumb-2.jpg" alt="JSOFT">
                            </div>
                        </div>
                        <!-- Articles Thumbnail End -->
                        <!-- Articles Content Start -->
                        <div class="col-lg-7">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <div class="article-body">
                                        <h3><a href="article-details.html">Nishu Sharma</a></h3>
                                        <div class="article-meta">
                                            <a href="#" class="author">By :: <span>Admin</span></a>
                                            <a href="#" class="commnet">Comments :: <span>10</span></a>
                                        </div>
                                        <div class="article-date">14<span class="month">feb</span></div>
                                        <p>At the outset, let me thank you for introducing Anytimehire(ATH) in Bangalore and for giving me an opportunity to use your service. Your customer support was impeccable and vehicle was well-maintained and top-notch.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Articles Content End -->
                        <!-- Articles Thumbnail Start -->
                        <div class="col-lg-5 d-none d-xl-block">
                            <div class="article-thumb">
                                <img src="<?=base_url()?>public/front/assets/img/article/arti-thumb-2.jpg" alt="JSOFT">
                            </div>
                        </div>
                        <!-- Articles Thumbnail End -->
                    </div>
                </article>
            </div>
            <!-- Single Articles End -->
            <!-- Single Articles Start -->
            <div class="col-lg-12">
                <article class="single-article">
                    <div class="row">
                        <!-- Articles Thumbnail Start -->
                        <div class="col-lg-5">
                            <div class="article-thumb">
                                <img src="<?=base_url()?>public/front/assets/img/article/arti-thumb-3.jpg" alt="JSOFT">
                            </div>
                        </div>
                        <!-- Articles Thumbnail End -->
                        <!-- Articles Content Start -->
                        <div class="col-lg-7">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <div class="article-body">
                                        <h3><a href="article-details.html">Deepak Singh</a></h3>
                                        <div class="article-meta">
                                            <a href="#" class="author">By :: <span>Admin</span></a>
                                            <a href="#" class="commnet">Comments :: <span>10</span></a>
                                        </div>
                                        <div class="article-date">17 <span class="month">feb</span></div>
                                        <p>I just wanted to let you know that I really appreciate the efforts you are making personally, to ensure that the customer is satisfied... I really hope you carry forward this culture and make a model for other companies..</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Articles Content End -->
                    </div>
                </article>
            </div>
            <!-- Single Articles End -->
        </div>
        <!-- Articles Content Wrap End -->
    </div>
</section>
<!--== Articles Area End ==-->
<!--== Footer Area Start ==-->
<?php
$this->load->view('front/includes/footer');
?>