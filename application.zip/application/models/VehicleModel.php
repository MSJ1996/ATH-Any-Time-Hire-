<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class VehicleModel extends CI_Model {

	public function __construct() {        
		parent::__construct();
	}
	public function getCategory(){
		$query=$this->db->get('vehicle_category');
		return $query->result_array();
	}

	public function addCategory($data){		
		$array=array('category_name' =>$data['category_name'] ,
			'description' =>$data['description']  );
		if($this->db->insert('vehicle_category',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function updateCategory($data){
		$array = array(  'category_name' =>$data['category_name'] ,
					     'description'=>$data['description']
						 );
		$this->db->where('id',$data['id']);
		if($this->db->update('vehicle_category',$array)){
			return true;
		}else{
			return false;
		}
	}
	public function getSubcategory(){
		$query=$this->db->query("SELECT vehicle_subcategory.*,vehicle_category.category_name
		FROM vehicle_subcategory
		INNER JOIN vehicle_category ON vehicle_subcategory.category_id = vehicle_category.id");		
		return $query->result_array();
	}

	public function addSubcategory($data){		
		$array=array('subcategory_name' =>$data['subcategory_name'] ,
			'description' =>$data['description'],
			'category_id' =>$data['category_id']  );
		if($this->db->insert('vehicle_subcategory',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function updateSubcategory($data){
		$array = array(  'subcategory_name' =>$data['subcategory_name'] ,
					     'description'=>$data['description'],
						 'category_id' =>$data['category_id']
						 );
		$this->db->where('id',$data['id']);
		if($this->db->update('vehicle_subcategory',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function getVehicle(){
		$query=$this->db->query("SELECT vehicle.*,vehicle_category.category_name,vehicle_subcategory.subcategory_name
		FROM vehicle
		INNER JOIN vehicle_category ON vehicle.category_id = vehicle_category.id
		INNER JOIN vehicle_subcategory ON vehicle.subcategory_id = vehicle_subcategory.id");
		return $query->result_array();
	}

	public function addVehicle($fnn,$data){
		$array = array(  'name' =>$data['name'] ,
					     'category_id'=>$data['category_id'],
					     'subcategory_id'=>$data['subcategory_id'],
					     'company_name'=>$data['company_name'],
					     'price'=>$data['price'],
					     'image'=>'public/vehicle/'.$fnn,
					     'description'=>$data['description']
						 );
		if($this->db->insert('vehicle',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function editVehicle($data){
		$array = array(  'name' =>$data['name'] ,
					     'category_id'=>$data['category_id'],
					     'subcategory_id'=>$data['subcategory_id'],
					     'company_name'=>$data['company_name'],
					     'price'=>$data['price'],					     
					     'description'=>$data['description']
						 );
		$this->db->where('id',$data['id']);
		if($this->db->update('vehicle',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function deleteVehicle($id){
		$this->db->where('id', $id);
		if($this->db->delete('vehicle')){
			return true;
		}else{
			return false;
		}
	}


	public function getVehicleById($id){
		$this->db->where('id',$id);
		$query=$this->db->get('vehicle');
		return $query->result_array();
	}
}
?>