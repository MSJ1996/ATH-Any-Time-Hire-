<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class BookingModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
	}

	public function getBookings(){
        
        $query="SELECT booking.*,frontuser.fname,frontuser.lname,vehicle.name FROM `booking` inner join vehicle on booking.vehicle_id=vehicle.id INNER JOIN frontuser on frontuser.id=booking.customer_id";
		$queryexe=$this->db->query($query);
		return $result=$queryexe->result_array();
			
		
	}



}
?>