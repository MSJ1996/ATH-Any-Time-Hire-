<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class AdminModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
	}
	public function getUserById($user_id){		
		$this->db->where('id',$user_id);
		$query=$this->db->get('users');
		return $query->result_array();
	}

	public function editUser($data){
		$this->db->where('id',$data['id']);
		$array = array('first_name' =>$data['first_name'],
						'last_name' =>$data['last_name'],
						'email' =>$data['email'],
						'phone' =>$data['phone'] );
		if($this->db->update('users',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function addContact($data){
		if($this->db->insert('contact',$data)){
			return true;
		}else{
			return false;
		}
	}
	public function getContact(){
		$query=$this->db->get('contact');
		return $query->result_array();
	}
	public function deleteContact($id){
		$this->db->where('id',$id);
		if($this->db->delete('contact')){
			return true;
		}else{
			return false;
		}
	}


}
?>