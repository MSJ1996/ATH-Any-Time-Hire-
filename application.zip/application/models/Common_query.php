<?php
 
class Common_query extends CI_Model
{
	
	//echo $this->db->last_query();
	public function __construct()
	{
		parent::__construct();
		
	}
	
	
	public function chk_unique($select,$from,$where)
	{
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query=$this->db->get();
		$count=$query->num_rows();
        /*echo $this->db->last_query();die;*/
		if($count)
		{
          return true;
		}else{
			return false;
		}

		
	}
    
    public function find_record($select,$from,$where)
	{
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query=$this->db->get();
		$count=$query->num_rows();

		if($count)
		{
          return true;
		}else{
			return false;
		}

		
	}

	public function insert($data,$table)
	{
		$this->db->insert($table,$data);
		$last_id=$this->db->insert_id();
		/* echo $this->db->last_query(); */
		return $last_id;
		
	}

	public function select($select,$from,$where=null,$single=null,$order=null)
	{
		$this->db->select($select);
		$this->db->from($from);
		if($where)
		{
		  $this->db->where($where);
		}
		
		if($order)
		{
		   
		   $this->db->order_by($order);

		}else{
          $this->db->order_by("id", "asc");  
		}
	
		$query=$this->db->get();
		$count=$query->num_rows();
		//echo $this->db->last_query(); die;
		if(!empty($count))
		{
			if(!empty($single)) $result=$query->result_array();
			if(empty($single)) $result=$query->row_array();
			return $result ;
          
		}else{
			return false;
		}
		
	}


	public function row_count($table,$whare=null)
	{
      $this->db->select('id');
      $this->db->from($table);
      if($whare){
      	$this->db->where($whare);
      }
      
      $query=$this->db->get();
      $count=$query->num_rows();
      if(!empty($count))
      {
        return $count ;
      }
	}

	public function customize_select($query,$single=null)
	{  
		
		$query=$this->db->query($query);
		$count=$query->num_rows();
        
   		if(!empty($count))
		{
			if(!empty($single)) $result=$query->result_array();
			if(empty($single)) $result=$query->row_array();
			return $result ;
          
		}else{
			return false;
		}
		
	}



	public function update($data,$table,$where=null)
	{   

		$this->db->where($where);
        $this->db->update($table, $data);
        //echo $this->db->last_query();
		return  true;
		
	}	

	public function customize_update ($query)
	{  
		$query=$this->db->query($query);
		 /*echo $this->db->last_query();die;*/
		return  true;
		
	}


	function delete($table,$where=null)
	{
	   $this->db->where($where);
	   $this->db->delete($table); 
	   $affected =$this->db->affected_rows();
	   if(!empty($affected))
	   {
	   	return $affected ;
	   }
	}



	
};