<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DriverModel extends CI_Model {

	public function __construct() {        
		parent::__construct();
	}
	public function getDrivers(){
		$query=$this->db->get('drivers');
		return $query->result_array();
	}
	public function addDriver($data, $fnn){
		$array = array(  'name' =>$data['name'] ,
					     'email'=>$data['email'],
					     'image'=>'public/drivers/'.$fnn,
					     'description'=>$data['description']
						 );
		if($this->db->insert('drivers',$array)){
			return true;
		}else{
			return false;
		}
	}

	public function updateDriver($data){
		$array = array('name' => $data['name'],'email' => $data['email'],'description' => $data['description'], );
		$this->db->where('id', $data['id']);
    	if($this->db->update('drivers', $array)){
    		return true;
    	}else{
    		return false;
    	}
	}

	public function deleteDriver($id){
		$this->db->where('id',$id);
		if($this->db->delete('drivers')){
			return true;
		}else{
			return false;
		}

	}



}
?>