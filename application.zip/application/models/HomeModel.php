<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class HomeModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
	}

	public function getCars(){
		$create_query="SELECT vehicle_category.category_name as cname ,vehicle_subcategory.subcategory_name as scname,vehicle.id as vid ,vehicle.name AS vname,vehicle.company_name as comname ,vehicle.image as vimage ,vehicle.price,vehicle.description from vehicle inner join vehicle_category on vehicle.category_id=vehicle_category.id 
		inner join vehicle_subcategory on vehicle.subcategory_id=vehicle_subcategory.id where vehicle_category.id=1
		";
		$query =$this->db->query($create_query);
		
		return $query->result_array();
	}

	public function getSingleCars($id){
		$create_query="SELECT vehicle_category.category_name as cname ,vehicle_subcategory.subcategory_name as scname,vehicle.id as vid ,vehicle.name AS vname,vehicle.company_name as comname ,vehicle.image as vimage ,vehicle.price,vehicle.description from vehicle inner join vehicle_category on vehicle.category_id=vehicle_category.id 
		inner join vehicle_subcategory on vehicle.subcategory_id=vehicle_subcategory.id where vehicle_category.id=1 AND vehicle.id=$id
		";
		$query =$this->db->query($create_query);
		
		return $query->result_array();
	}

	public function getBikes(){
		$create_query="SELECT vehicle_category.category_name as cname ,vehicle_subcategory.subcategory_name as scname,vehicle.id as vid ,vehicle.name AS vname,vehicle.company_name as comname ,vehicle.image as vimage ,vehicle.price,vehicle.description from vehicle inner join vehicle_category on vehicle.category_id=vehicle_category.id 
		inner join vehicle_subcategory on vehicle.subcategory_id=vehicle_subcategory.id where vehicle_category.id=2
		";
		$query =$this->db->query($create_query);
		
		return $query->result_array();
	}
	public function getCycles(){
		$create_query="SELECT vehicle_category.category_name as cname ,vehicle_subcategory.subcategory_name as scname,vehicle.id as vid ,vehicle.name AS vname,vehicle.company_name as comname ,vehicle.image as vimage ,vehicle.price,vehicle.description from vehicle inner join vehicle_category on vehicle.category_id=vehicle_category.id 
		inner join vehicle_subcategory on vehicle.subcategory_id=vehicle_subcategory.id where vehicle_category.id=3
		";
		$query =$this->db->query($create_query);
		
		return $query->result_array();
	}

	public function getDrivers(){
		$query=$this->db->get('drivers');
		return $query->result_array();
	}

	public function getSubcategory(){
		$this->db->where('category_id','1');
		$query=$this->db->get('vehicle_subcategory');
		return $query->result_array();
	}

	public function getAllCarSubcategoryWise(){
		$subcategory=$this->getSubcategory();
		if(!empty($subcategory)){
			foreach ($subcategory as $skey => $svalue) {
				$sid=$svalue['id'];
				$create_query="SELECT vehicle_category.category_name as cname ,vehicle_subcategory.subcategory_name as scname,vehicle.id as vid ,vehicle.name AS vname,vehicle.company_name as comname ,vehicle.image as vimage ,vehicle.price,vehicle.description from vehicle inner join vehicle_category on vehicle.category_id=vehicle_category.id 
				inner join vehicle_subcategory on vehicle.subcategory_id=vehicle_subcategory.id where vehicle_subcategory.id=$sid
				";
				$query =$this->db->query($create_query);
				$getcarresult=$query->result_array();
				if($getcarresult){
					$subcategory[$skey]['cars']=$getcarresult;

				}else{
                 $getcarresult="";
                 $subcategory[$skey]['cars']=$getcarresult;

				}
			}
		}
      /*echo "<pre>";
      print_r($subcategory);die;*/
      return $subcategory;
	}





}
?>