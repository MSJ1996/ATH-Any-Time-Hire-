<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class ProcessModel extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
	}
	
	public function changeUserProfilePic($fnn){
		$user_id=$this->session->userdata('user_id');
		$this->db->where('id',$user_id);
		$array = array('image' =>'public/profile/'.$fnn);
		if($this->db->update('users',$array)){
			return ture;
		}else{
			return false;
		}
	}

	 public function getSubcategoryByCatId($cid){
	 	$this->db->where('category_id', $cid);
	 	$query=$this->db->get('vehicle_subcategory');
	 	return $query->result_array();
	 }






}

?>