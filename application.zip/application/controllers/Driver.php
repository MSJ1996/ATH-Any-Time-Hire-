<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Driver extends CI_Controller {

	public function __construct() {        
		parent::__construct();
		$this->load->model('DriverModel');
	}
	
	public function index()
	{
		$data['drivers']= $this->DriverModel->getDrivers();
		$this->load->view('auth/drivers/index',$data);
	}
	public function addDriver()
	{
		extract($_POST);
		$fn=$_FILES['image']['name'];
		$ext = pathinfo($fn,PATHINFO_EXTENSION);
		$fnn=rand().'.'.$ext;
		$config['upload_path'] = './public/drivers';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['file_name']=$fnn;
		$this->upload->initialize($config);
		if ( ! $this->upload->do_upload('image'))
		{
			$this->session->set_flashdata('error', "Only JPG and PNG files allow");
			redirect('driver/index');
		}
		else
		{
			if($this->DriverModel->addDriver($_POST,$fnn)){
				$this->session->set_flashdata('success', "Added Successfully");
				redirect('driver/index');
			}else{
				$this->session->set_flashdata('error', "Something Went Wrong Please Try Again");
				redirect('driver/index');
			}
		}
	}

	public function updateDriver(){
		extract($_POST);
		if($this->DriverModel->updateDriver($_POST)){
				$this->session->set_flashdata('success', "Updated Successfully");
				redirect('driver/index');
			}else{
				$this->session->set_flashdata('error', "Something Went Wrong Please Try Again");
				redirect('driver/index');
			}
	}

	public function deleteDriver($id){
		if($this->DriverModel->deleteDriver($id)){
				$this->session->set_flashdata('success', "Deleted Successfully");
				redirect('driver/index');
			}else{
				$this->session->set_flashdata('error', "Something Went Wrong Please Try Again");
				redirect('driver/index');
		}
	}
}
