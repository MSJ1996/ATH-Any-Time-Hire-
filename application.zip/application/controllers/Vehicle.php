<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicle extends CI_Controller {

	public function __construct() {        
		parent::__construct();
		$this->load->model('VehicleModel');
	}
	public function category()
	{
		$data['categoryData']=$this->VehicleModel->getCategory();
		$this->load->view('auth/vehicle/category',$data);
	}
	public function AddCategory()
	{
		extract($_POST);		
		if($this->VehicleModel->addCategory($_POST)){
			$this->session->set_flashdata('success','Category Added Successfully');
			redirect('vehicle/category');
		}else{
			$this->session->set_flashdata('error','Category Name Already Added');
			redirect('vehicle/category');
		}

	}
	public function updateCategory()
	{
		extract($_POST);		
		if($this->VehicleModel->updateCategory($_POST)){
			$this->session->set_flashdata('success','Updated Successfully');
			redirect('vehicle/category');
		}else{
			$this->session->set_flashdata('error','Category Name Already Added');
			redirect('vehicle/category');
		}	
	}
	public function subcategory()
	{
		$data['categoryData']=$this->VehicleModel->getCategory();
		$data['subcategoryData']=$this->VehicleModel->getSubcategory();
		$this->load->view('auth/vehicle/subcategory',$data);
	}
	public function addSubcategory()
	{
		extract($_POST);		
		if($this->VehicleModel->addSubcategory($_POST)){
			$this->session->set_flashdata('success','Sub-category Added Successfully');
			redirect('vehicle/subcategory');
		}else{
			$this->session->set_flashdata('error','Sub-category Name Already Added');
			redirect('vehicle/subcategory');
		}

	}
	public function updateSubcategory()
	{
		extract($_POST);		
		if($this->VehicleModel->updateSubcategory($_POST)){
			$this->session->set_flashdata('success','Updated Successfully');
			redirect('vehicle/subcategory');
		}else{
			$this->session->set_flashdata('error','Category Name Already Added');
			redirect('vehicle/subcategory');
		}	
	}
	public function vehicle()
	{
		$data['category']=$this->VehicleModel->getCategory();
		// $data['subcategory']=$this->VehicleModel->getSubcategory();
		$data['vehicle']=$this->VehicleModel->getVehicle();
		$this->load->view('auth/vehicle/vehicle',$data);
	}
	public function AddVehicle()
	{
		extract($_POST);
		$fn=$_FILES['image']['name'];
		$ext = pathinfo($fn,PATHINFO_EXTENSION);
		$fnn=rand().'.'.$ext;
		$config['upload_path'] = './public/vehicle';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['file_name']=$fnn;
		$this->upload->initialize($config);
		if ( ! $this->upload->do_upload('image'))
		{
			$this->session->set_flashdata('error', "Only JPG and PNG files allow");
			redirect('vehicle/vehicle');
		}
		else
		{
			if($this->VehicleModel->addVehicle($fnn,$_POST)){
				$this->session->set_flashdata('success', "Added Successfully");
				redirect('vehicle/vehicle');
			}else{
				$this->session->set_flashdata('error', "Something Went Wrong Please Try Again");
				redirect('vehicle/vehicle');
			}
		}
	}
	public function UpdateVehicle($id)
	{
		$data['vehicle']=$this->VehicleModel->getVehicleById($id);
		$data['category']=$this->VehicleModel->getCategory();
		$data['subcategory']=$this->VehicleModel->getSubcategory();
		$this->load->view('auth/vehicle/edit_vehicle',$data);
	}
	public function editVehicle(){
		extract($_POST);
		if($this->VehicleModel->editVehicle($_POST)){
		$this->session->set_flashdata('success', "Updated Successfully");
			redirect('vehicle/vehicle');
		}else{
			$this->session->set_flashdata('error', "Something Went Wrong Please TryAgain");
			redirect('vehicle/vehicle');
		}
	}

	public function deleteVehicle($id){
		if($this->VehicleModel->deleteVehicle($id)){
		$this->session->set_flashdata('success', "Deleted Successfully");
			redirect('vehicle/vehicle');
		}else{
			$this->session->set_flashdata('error', "Something Went Wrong Please TryAgain");
			redirect('vehicle/vehicle');
		}
	}

	


}
