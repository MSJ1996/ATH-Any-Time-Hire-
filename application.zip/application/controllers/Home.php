<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {        
		parent::__construct();
		$this->load->model('HomeModel');
	}

	public function index(){ 
		$this->session->unset_userdata('display');
		$this->session->unset_userdata('insert');
		$data['subcategory']=$this->HomeModel->getSubcategory();
		$data['getAllCarSubcategoryWise']=$this->HomeModel->getAllCarSubcategoryWise();
		//$data['cars']=$this->HomeModel->getCars();
		$this->load->view('front/index',$data);
	}
	public function booking(){
		$data['getCars']=$this->HomeModel->getCars();
		$this->load->view('front/booking',$data);
	}

	public function submitbooking(){
		$this->load->library('form_validation');         
		$tbl_frntuser='frontuser';
		$post=$this->input->post(); 
		$this->form_validation->set_rules('pickup_location', 'Pickup location', 'trim|required');
		$this->form_validation->set_rules('drop_location', 'Drop location', 'trim|required');
		$this->form_validation->set_rules('pick_up_date', 'Pick up date', 'trim|required');
		$this->form_validation->set_rules('return_date', 'Return_date', 'trim|required');
		$this->form_validation->set_rules('vehicle_id', 'Vehicle id', 'required');
		if ($this->form_validation->run() == FALSE)
		{  
			$error= validation_errors();
			$this->session->set_flashdata('status',0);
			$this->session->set_flashdata('message',$error);
			$redirect_url=base_url('Home/booking');               
			redirect($redirect_url);
		}else{
			$this->session->set_userdata(array('BookingFormData'=>$post));
			$redirect_url=base_url('Home/carSection');               
			redirect($redirect_url);	
		} 
	}

	public function chkbooking_session(){
        
		$session=$this->session->userdata('ATSSESSION');		
		$formbookingsession=$this->session->userdata('BookingFormData');
        $post=$this->input->post();
     if($formbookingsession['pickup_location'] && $session['fname']){
        $this->session->set_userdata('SelectCar',$post);
     	echo json_encode(array('status'=>1));
     }else{
     echo json_encode(array('status'=>0));
     }
     
	}

	public function about(){
		$this->load->view('front/about');
	}
	public function services(){
		$this->load->view('front/services');
	}
	public function pricing(){
		$this->load->view('front/package');
	}
	public function faq(){
		$this->load->view('front/faq');
	}
	public function gallery(){
		$this->load->view('front/gallery');
	}
    public function cardPayment(){

	$pickup=array("Maharastra/Pune","Delhi/NCR","Bangolre","Hyderabad");
	$dropup=array("Maharastra/Pune","Delhi/NCR","Bangolre","Hyderabad"); 
	
   
	$session=$this->session->userdata('ATSSESSION'); 		
    $formbookingsession=$this->session->userdata('BookingFormData');
    $SelectCar=$this->session->userdata('SelectCar'); 
    $cardetails =$this->HomeModel->getSingleCars($formbookingsession['vehicle_id']);

    $selpickup=$pickup[$formbookingsession['pickup_location']];
    $seldrop=$pickup[$formbookingsession['drop_location']]; 

    $display=array('pickup_location'=>$selpickup,'drop_location'=>$seldrop,'pick_up_date'=>$formbookingsession['pick_up_date'],'return_date'=>$formbookingsession['return_date'],'vehicle_id'=>$cardetails[0]['vname'],'price'=>$SelectCar['price'],'image'=>$cardetails[0]['vimage']);
    $data['display']=$display;

    $insert=array('customer_id'=>$session['id'],'pickup_location'=>$formbookingsession['pickup_location'],'drop_location'=>$formbookingsession['drop_location'],'pick_up_date'=>$formbookingsession['pick_up_date'],'return_date'=>$formbookingsession['return_date'],'vehicle_id'=>$SelectCar['id'],'price'=>$SelectCar['price']);

    $data['display']=$display;
    $data['insert']=$insert;


    $this->session->set_userdata('display',$display);
    $this->session->set_userdata('insert',$insert);
	$this->load->view('front/card',$data);  

}
public function bookingpayment(){
	   $session=$this->session->userdata('ATSSESSION'); 
	   $display=$this->session->userdata('display'); 
	   $insertdata=$this->session->userdata('insert'); 
	   $useremail=$session['email'];
	   $username=$session['fname']." ".$session['lname'];
	   $subject = 'ATH Booking';
	
    
   if(!empty($display) && !empty($insertdata) ){
  $message = "<html><body>";
	$message .= "<h1 style='color:#f40;'>Hi $username!</h1>";
	$message .= "<p style='color:#080;font-size:11px;'>Thanks for Booking from my ATH system</p>";
	$message .= "<p style='color:#080;font-size:18px;'>Details </p>";
	$message .= "<p style='color:#080;font-size:11px;'>PickUp Location :- ".$display['pickup_location']."</p>";
	$message .= "<p style='color:#080;font-size:11px;'>DropOff Location :-".$display['drop_location']."</p>";

	$message .= "<p style='color:#080;font-size:11px;'>Pick date :-".$display['pick_up_date']."</p>";
	$message .= "<p style='color:#080;font-size:11px;'>Return date :-".$display['return_date']."</p>";
	$message .= "</body></html>";
	$insert=$this->Common_query->insert($insertdata,'booking');
	$this->load->library('ion_auth');
	$this->ion_auth->send_mail($useremail,$subject,$message);
	echo "yes";

   }else{
   	echo "no";
   }
    
		
	}

	public function helpDesk(){
		$this->load->view('front/help-desk');
	}
	public function blogPage(){
		$this->load->view('front/article');
	}
	public function contact(){
		$this->load->view('front/contact');
	}
	public function carSection(){
		$data['cars']=$this->HomeModel->getCars();
		$this->load->view('front/car-without-sidebar',$data);
	}
	public function bikeSection(){
		$data['bikes']=$this->HomeModel->getBikes();
		$this->load->view('front/bike-without-sidebar',$data);
	}
	public function cycleSection(){
		$data['cycles']=$this->HomeModel->getCycles();
		$this->load->view('front/cycle-without-sidebar',$data);
	}
	public function customerProfile(){
		$this->load->view('front/customer');
	}
	public function invoiceProfile(){
		$this->load->view('front/invoice');
	}
	public function driverProfile(){
		$data['drivers']=$this->HomeModel->getDrivers();
		$this->load->view('front/driver',$data);
	}

	public function login(){
		$session=$this->session->userdata('ATSSESSION');
		if(empty($session['fname'])){
			$this->load->view('front/login');
		}else{
			redirect(base_url('home'));
		}
	}

	public function registration(){
		$session=$this->session->userdata('ATSSESSION');
		if(empty($session['fname'])){
			$this->load->view('front/register');
		}else{
			redirect(base_url('home'));
		}
	}

	public function submitregistration(){ 
		$this->load->library('form_validation');         
		$tbl_frntuser='frontuser';
		$post=$this->input->post(); 
		unset($post[0]);
		unset($post['submit']);
		$this->form_validation->set_rules('fname', 'First Name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('uname', 'User Name', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
		if ($this->form_validation->run() == FALSE)
		{  
			$error= validation_errors();
			$this->session->set_flashdata('status',0);
			$this->session->set_flashdata('message',$error);
		}else{           
			unset($post['cpassword']); 
			$post['password']=md5($post['password'])  ;
			$where=array( 'email'=>$_POST['email']);            
			$select="id";
			$sel_info=$this->Common_query->select($select,$tbl_frntuser,$where);
			if($sel_info['id'])
			{
				$this->session->set_flashdata('status',0);
				$this->session->set_flashdata('message','Email is exists'); 
				$redirect_url=base_url('bck_useradd');               
				redirect($redirect_url); 
			}
			$insert=$this->Common_query->insert($post,$tbl_frntuser);
			if($insert){
				$this->session->set_flashdata('status',1);
				$this->session->set_flashdata('message','Now You can Login');  
			}else{
				$this->session->set_flashdata('status',0);
				$this->session->set_flashdata('message','Oops! Something error');  
			}
		}
		$redirect_url=base_url('Home/registration');               
		redirect($redirect_url);
	}



	public function slogin()
	{  
		$post=$this->input->post();
		if(!empty($post['email']) && !empty($post['password']))
		{
			$table='frontuser';	
			$select='id';		
			$where=array( 'email'=>$_POST['email'] ,'password'=>md5($post['password']) );
			$chk_user=$this->Common_query->chk_unique($select,$table,$where);
			if($chk_user)
			{   
				$where=array( 'email'=>$_POST['email']);
				$select="id,fname,lname,email";
				$sel_info=$this->Common_query->select($select,$table,$where);                
				if(!empty($sel_info))
				{   
					$user_session=array('ATSSESSION'=>$sel_info);
					$this->session->set_userdata($user_session);
					redirect(base_url('home'));
				}else{
					$this->session->set_flashdata('status',0);
					$this->session->set_flashdata('message','Oops ! database error');
					redirect(base_url('home/login'));
				}
			}else{
				$this->session->set_flashdata('status',0);
				$this->session->set_flashdata('message','Login credential wrong');
				redirect(base_url('home/login'));
			}
		}else{ 
			$this->session->set_flashdata('status',0);
			$this->session->set_flashdata('message','Please fill the credentials');
			redirect(base_url('home/login'));
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url('home'));
	}



}
?>
