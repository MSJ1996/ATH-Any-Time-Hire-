<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Process extends CI_Controller {

	public function __construct()
    {
        parent::__construct();  
        $this->load->model('ProcessModel');              
    }
    public function profilepic()
    {    	
    extract($_POST);
    $fn=$_FILES['image']['name'];
    $ext = pathinfo($fn,PATHINFO_EXTENSION);
    $fnn=rand().'.'.$ext;
    $config['upload_path'] = './public/profile';
    $config['allowed_types'] = 'gif|jpg|png';
    $config['file_name']=$fnn;
    $this->upload->initialize($config);
    if ( ! $this->upload->do_upload('image'))
    {
      $this->session->set_flashdata('error', "Only JPG and PNG files allow");
      redirect('admin/myProfile');
    }
    else
    {
      if($this->ProcessModel->changeUserProfilePic($fnn)){
      $this->session->set_flashdata('success', "Profile Picture Changes Successfully");
        redirect('admin/myProfile');
      }else{
        $this->session->set_flashdata('error', "Something Went Wrong Please Try Again");
        redirect('admin/myProfile');
      }
    }
  
  }

  public function getSubcategoryByCatId($cid){
    $result=$this->ProcessModel->getSubcategoryByCatId($cid);
    print_r(json_encode($result));
  }



}
?>