<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct() {        
		parent::__construct();
		
	}
	public function myProfile()
	{
		$user_id=$this->session->userdata('user_id');
		$data['userdata']=$this->AdminModel->getUserById($user_id);
		$this->load->view('auth/user/profile',$data);
	}
	public function editUser(){
		extract($_POST);
		if($this->AdminModel->editUser($_POST)){
			$this->session->set_flashdata('success','Updated Successfully');
			redirect('Admin/myProfile');
		}else{
			$this->session->set_flashdata('error','Something went wrong');
			redirect('Admin/myProfile');
		}
	}
	public function addContact(){
		$this->load->library('ion_auth');
		extract($_POST);
		if($this->AdminModel->addContact($_POST)){
			$this->ion_auth->send_mail($_POST['email'],'ATH ENQUIRY','Thanks to contact us.Our memeber contact you soon');
			$this->session->set_flashdata('success','Thank You for Connecting with us');
			redirect('Home/contact');
		}else{
			$this->session->set_flashdata('error','Something went wrong');
			redirect('Home/contact');
		}
	}

	public function contact(){
		$data['contacts']=$this->AdminModel->getContact();
		$this->load->view('auth/contact',$data);
	}
	public function deleteContact($id){
		if($this->AdminModel->deleteContact($id)){
			$this->session->set_flashdata('success','Deleted Successfully');
			redirect('admin/contact');
		}else{
			$this->session->set_flashdata('error','Something went wrong');
			redirect('admin/contact');
		}
	}
}
